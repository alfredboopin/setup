import { cn } from "../utils/cn";
import { Button, Card, Chip, MicroLabel, Stat, Tooltip } from "../components/ui";
import { Check, Folder, Key, Link, Rocket, Shield, Terminal, Trash, Book } from "../components/Icons";
import { fmtClock, type ComponentFlags } from "../lib/installer";
import { shortcuts } from "../lib/spec";

export function Finish({
  variant,
  elapsedMs,
  targetPath,
  components,
  upgrade,
  preserveSettings,
  launch,
  setLaunch,
  purge,
  setPurge,
  onShowLog,
  logPath,
}: {
  variant: "install" | "uninstall";
  elapsedMs: number;
  targetPath: string;
  components: ComponentFlags;
  upgrade: boolean;
  preserveSettings: boolean;
  launch: boolean;
  setLaunch: (v: boolean) => void;
  purge: boolean;
  setPurge: (v: boolean) => void;
  onShowLog: () => void;
  logPath: string;
}) {
  const install = variant === "install";

  const rows = [
    components.shortcut && shortcuts[0],
    components.shortcut && shortcuts[1],
    shortcuts[2],
    components.pathEntry && shortcuts[3],
    components.contextMenu && shortcuts[4],
  ].filter(Boolean) as typeof shortcuts;

  return (
    <div className="scroll-thin min-h-0 flex-1 overflow-y-auto pr-1">
      <div className="flex items-start gap-5">
        {/* -------------------------------------------------------- success mark */}
        <div className="relative mt-1 grid h-[76px] w-[76px] shrink-0 place-items-center">
          <span
            className={cn(
              "ring-pulse absolute h-[58px] w-[58px] rounded-full border",
              install ? "border-phos-400/70" : "border-phos-400/50",
            )}
          />
          <span
            className={cn(
              "absolute h-[58px] w-[58px] rounded-full border",
              install ? "border-phos-500/40 bg-phos-900/50 shadow-[0_0_40px_-6px_rgb(61_220_100/0.55)]" : "border-phos-500/30 bg-phos-900/40",
            )}
          />
          <svg viewBox="0 0 100 100" className="relative h-[74px] w-[74px] text-phos-300">
            <path
              d="M28 52.5 43 67l29-33"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="draw-check"
            />
          </svg>
        </div>

        <div className="min-w-0 flex-1">
          <div className="label-micro">{install ? "setup complete" : "removal complete"}</div>
          <h2 className="mt-1.5 flex items-baseline font-display text-[24px] font-bold leading-tight tracking-[-0.01em] text-txt-1">
            {install ? "KAEL 1.0.5 is installed" : "KAEL has been removed."}
            <span className="caret ml-2 h-[19px] w-[9px] text-phos-500" />
          </h2>
          <p className="mt-2 max-w-[430px] font-mono text-[11.5px] leading-[18px] text-txt-2">
            {install
              ? "The console is staged and sealed. First launch provisions your keybindings and opens a warm session in the last-used workspace."
              : "Binaries, runtime, shell links and registry keys are gone. Zero orphaned entries remain on this volume."}
          </p>

          <div className="mt-3.5 flex flex-wrap items-center gap-2">
            {install ? (
              <>
                <Chip tone="phos">
                  <Check width={11} height={11} /> signature verified
                </Chip>
                <Chip>v1.0.5 · build 26100.1043</Chip>
                <Chip tone="dusk">no reboot required</Chip>
              </>
            ) : (
              <>
                <Chip tone="phos">
                  <Check width={11} height={11} /> 412.7 MB freed
                </Chip>
                <Chip tone="dusk">reboot not required</Chip>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-[1fr_252px] gap-3.5">
        {/* ---------------------------------------------------------- left column */}
        <div className="space-y-3.5">
          {install ? (
            <Card className="p-3.5">
              <div className="flex items-center gap-2">
                <MicroLabel>next</MicroLabel>
                <span className="h-px flex-1 bg-white/[0.08]" />
              </div>
              <button
                type="button"
                role="checkbox"
                aria-checked={launch}
                onClick={() => setLaunch(!launch)}
                className={cn(
                  "mt-3 flex w-full items-center gap-3 rounded-[10px] border px-3 py-2.5 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
                  launch ? "border-phos-500/35 bg-phos-900/40" : "border-white/[0.09] bg-white/[0.02] hover:border-white/16",
                )}
              >
                <span
                  className={cn(
                    "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-all",
                    launch ? "border-phos-500 bg-phos-500 text-obsidian" : "border-white/20 text-transparent",
                  )}
                >
                  <Check width={12} height={12} className={launch ? "draw-check" : ""} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-[13px] font-semibold tracking-tight text-txt-1">Launch KAEL</span>
                  <span className="mt-0.5 block font-mono text-[10.5px] tracking-tight text-txt-3">
                    starts as your user · no elevation · logs to %LOCALAPPDATA%\KAEL\logs
                  </span>
                </span>
                <Rocket width={15} height={15} className={launch ? "text-phos-400" : "text-txt-3"} />
              </button>
            </Card>
          ) : (
            <Card tone="amber" className="p-3.5">
              <div className="flex items-center gap-2">
                <MicroLabel>residual data</MicroLabel>
                <span className="h-px flex-1 bg-white/[0.08]" />
                <span className="font-mono text-[10px] text-amber-300">1.2 MB</span>
              </div>
              <p className="mt-2.5 font-mono text-[11px] leading-[17px] text-txt-2">
                %APPDATA%\KAEL retains config.json, sessions\ and keybindings.kael in case you reinstall.
              </p>
              <button
                type="button"
                role="checkbox"
                aria-checked={purge}
                onClick={() => setPurge(!purge)}
                className={cn(
                  "mt-2.5 flex w-full items-center gap-3 rounded-[10px] border px-3 py-2.5 text-left transition-all duration-150",
                  purge ? "border-alert-400/45 bg-alert-900/60" : "border-white/[0.09] bg-white/[0.02] hover:border-white/16",
                )}
              >
                <span
                  className={cn(
                    "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-all",
                    purge ? "border-alert-400 bg-alert-400 text-obsidian" : "border-white/20 text-transparent",
                  )}
                >
                  <Check width={12} height={12} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className={cn("block font-display text-[12.5px] font-semibold tracking-tight", purge ? "text-alert-400" : "text-txt-1")}>
                    Also purge settings & sessions
                  </span>
                  <span className="mt-0.5 block font-mono text-[10.5px] tracking-tight text-txt-3">
                    irreversible · deletes %APPDATA%\KAEL and console history
                  </span>
                </span>
                <Trash width={15} height={15} className={purge ? "text-alert-400" : "text-txt-3"} />
              </button>
            </Card>
          )}

          <Card className="p-3.5">
            <div className="flex items-center gap-2">
              <MicroLabel>{install ? "shortcuts & integration" : "integration released"}</MicroLabel>
              <span className="h-px flex-1 bg-white/[0.08]" />
            </div>
            <div className="mt-3 space-y-2">
              {rows.map((s, i) => (
                <div key={s.label} className="flex items-start gap-2.5">
                  <span className={cn("mt-[1px] shrink-0", install ? "text-phos-400/80" : "text-txt-3")}>
                    {i === 0 || i === 1 ? (
                      <Folder width={13} height={13} />
                    ) : i === 2 ? (
                      <Key width={13} height={13} />
                    ) : i === 3 ? (
                      <Terminal width={13} height={13} />
                    ) : (
                      <Link width={13} height={13} />
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-mono text-[11px] tracking-tight text-txt-2">{s.label}</span>
                    <Tooltip text={s.path} side="top" className="mt-[2px] block">
                      <span className="block w-full truncate font-mono text-[10px] tracking-tight text-txt-3">{s.path}</span>
                    </Tooltip>
                  </span>
                  {install ? <Check width={12} height={12} className="mt-[3px] shrink-0 text-phos-500/80" /> : <span className="mt-[3px] shrink-0 font-mono text-[9.5px] uppercase tracking-[0.14em] text-txt-3">removed</span>}
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* --------------------------------------------------------- right column */}
        <div className="space-y-3.5">
          <Card className="p-3.5">
            <MicroLabel>{install ? "install report" : "removal report"}</MicroLabel>
            <div className="mt-3">
              <Stat k="elapsed" v={<span className="text-phos-300">{fmtClock(elapsedMs)}</span>} />
              <Stat k={install ? "disk used" : "disk freed"} v={install ? "412.7 MB" : "412.7 MB"} tone="phos" />
              <Stat k="objects" v="3,412" />
              <Stat k="registry keys" v={install ? "6 written" : "6 released"} />
              {install && upgrade ? (
                <Stat k="settings preserved" v={preserveSettings ? "v1.0.5 → 1.0.5" : "reset to defaults"} tone={preserveSettings ? "phos" : "amber"} />
              ) : null}
              {!install ? <Stat k="user data" v={purge ? "purged" : "1.2 MB retained"} tone={purge ? "amber" : undefined} /> : null}
            </div>
          </Card>

          <Card className="p-3.5">
            <MicroLabel>where</MicroLabel>
            <div className="mt-2.5">
              <Tooltip text={targetPath} className="block">
                <span className="block w-full truncate font-mono text-[10.5px] tracking-tight text-txt-2">{targetPath}</span>
              </Tooltip>
              <div className="mt-1.5">
                <Tooltip text={logPath} className="block">
                  <span className="block w-full truncate font-mono text-[10px] tracking-tight text-txt-3">{logPath}</span>
                </Tooltip>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2 border-t border-white/[0.07] pt-3">
              <Button size="sm" variant="ghost" icon={<Book width={12} height={12} />} onClick={onShowLog}>
                view log
              </Button>
              <span className="flex items-center gap-1.5 font-mono text-[10px] tracking-tight text-txt-3">
                <Shield width={12} height={12} className="text-phos-500/80" /> signed
              </span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
