import { useEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Card, Chip, Notice } from "../components/ui";
import { Check, Shield, Warn, ChevronDown } from "../components/Icons";

const CLAUSES: { h: string; p: string[] }[] = [
  {
    h: "1 · Grant of licence",
    p: [
      "Kael Systems Ltd. grants you a non-exclusive, non-transferable licence to install and use KAEL (\"the Software\") on any number of machines you own or control, for the term of your subscription or perpetual entitlement.",
      "Each named operator seat includes a signed local configuration, offline glyph pack, and the kael:// protocol handler registration on the licence holder's profile.",
    ],
  },
  {
    h: "2 · Restrictions",
    p: [
      "You may not reverse engineer, decompile, or repackage the Software except to the extent permitted by applicable law. Redistribution of the installer, the embedded payload, or any theme pack outside your organisation requires written consent.",
      "The Software may not be used to operate weapons systems, life-support systems, or any deployment in which failure of the console could result in personal injury.",
    ],
  },
  {
    h: "3 · Telemetry",
    p: [
      "None. KAEL performs zero outbound requests during installation and at runtime. Crash reports are written locally to %LOCALAPPDATA%\\KAEL\\logs and are never transmitted unless you attach them to a support thread yourself.",
      "The installer's audit log is written to %TEMP%\\kael-setup-<timestamp>.log and may be copied by you into a support ticket.",
    ],
  },
  {
    h: "4 · Sessions, configuration and data",
    p: [
      "Session transcripts, keybindings, and console history are stored in %APPDATA%\\KAEL. Upgrading from v1.0.x preserves these files verbatim; uninstalling retains them unless you explicitly request a full purge.",
      "You remain the controller of any data you type into the console. Do not paste production secrets into sessions you intend to share.",
    ],
  },
  {
    h: "5 · Updates, repair and termination",
    p: [
      "Offline MSI deltas are provided quarterly. This agreement terminates automatically if you materially breach clause 2; on termination you must remove the Software and any redistributed theme packs.",
      "KAEL setup registers a repair entry in Apps & Features. Repair reinstalls binaries without touching your configuration or sessions.",
    ],
  },
  {
    h: "6 · Warranty and liability",
    p: [
      "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.",
      "IN NO EVENT SHALL KAEL SYSTEMS LTD. BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY ARISING FROM THE USE OF THE SOFTWARE. Nothing limits liability for gross negligence or wilful misconduct.",
    ],
  },
  {
    h: "7 · Export compliance",
    p: [
      "You confirm you are not located in, or a national of, a jurisdiction subject to comprehensive trade sanctions, and that you will not export the Software contrary to applicable export control law.",
    ],
  },
  {
    h: "8 · Governing law",
    p: [
      "This agreement is governed by the laws of Ireland, excluding its conflict-of-law rules. Disputes are settled in the courts of Dublin.",
      "By continuing, you acknowledge that you have read this agreement. Last revised 2026-01-14 · agreement ID KAE-EULA-1.0.5.",
    ],
  },
];

export function License({
  accepted,
  onAccept,
  onScrollProgress,
}: {
  accepted: boolean;
  onAccept: (v: boolean) => void;
  onScrollProgress?: (pct: number) => void;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [unlocked, setUnlocked] = useState(false);

  const measure = () => {
    const el = boxRef.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    const p = max <= 4 ? 100 : Math.min(100, Math.round((el.scrollTop / max) * 100));
    setProgress(p);
    onScrollProgress?.(p);
    if (p >= 99) setUnlocked(true);
  };

  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const t = window.setTimeout(measure, 60);
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => {
      window.clearTimeout(t);
      ro.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3.5">
      <div className="flex items-start gap-3">
        <Card className="flex min-h-0 flex-1 flex-col overflow-hidden p-0">
          <div className="flex items-center gap-2.5 border-b border-white/[0.07] bg-white/[0.02] px-3.5 py-2.5">
            <Shield width={14} height={14} className="text-phos-400/90" />
            <span className="font-display text-[13px] font-semibold tracking-tight text-txt-1">End-user licence agreement</span>
            <span className="flex-1" />
            <Chip tone="dusk">KAE-EULA-1.0.5</Chip>
          </div>

          <div className="relative min-h-0 flex-1">
            <div
              ref={boxRef}
              onScroll={measure}
              tabIndex={0}
              role="region"
              aria-label="Licence agreement, scrollable"
              className="scroll-thin absolute inset-0 overflow-y-auto px-4 py-3.5"
            >
              <p className="font-mono text-[11px] leading-[18px] text-txt-3">
                Carefully read the following terms before installing. Use ↕ / PgDn / End, or drag the scrollbar. The acceptance control unlocks once the
                document has been read to the end.
              </p>
              <div className="mt-3.5 space-y-4">
                {CLAUSES.map((c) => (
                  <div key={c.h}>
                    <h3 className="font-mono text-[11.5px] uppercase tracking-[0.14em] text-phos-300/90">{c.h}</h3>
                    {c.p.map((p, i) => (
                      <p key={i} className="mt-1.5 font-mono text-[11.5px] leading-[19px] text-txt-2">
                        {p}
                      </p>
                    ))}
                  </div>
                ))}
                <div className="rounded-[10px] border border-white/[0.07] bg-black/40 p-3 font-mono text-[10.5px] leading-[17px] text-txt-3">
                  — END OF AGREEMENT — <br />
                  sha256 4f19c2…b8 · stored locally at %ProgramFiles%\KAEL\licence.txt
                </div>
              </div>
            </div>

            {/* edge fades */}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-[#0a0c0b] to-transparent" />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#0a0c0b] via-[#0a0c0b]/80 to-transparent" />

            {!unlocked ? (
              <div className="pointer-events-none absolute bottom-2.5 left-1/2 -translate-x-1/2">
                <span className="flex items-center gap-2 rounded-full border border-amber-400/35 bg-[#120d07]/95 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-amber-300 shadow-glow-amber">
                  <ChevronDown width={12} height={12} className="animate-bounce" />
                  scroll to unlock acceptance
                </span>
              </div>
            ) : null}
          </div>

          {/* scroll progress */}
          <div className="relative h-[3px] shrink-0 bg-black/60">
            <div
              className={cn("absolute inset-y-0 left-0 transition-all duration-200 ease-[var(--ease-out-kael)]", unlocked ? "bg-phos-500" : "bg-amber-400/80")}
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex items-center justify-between border-t border-white/[0.07] bg-white/[0.015] px-3.5 py-2.5">
            <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3">
              {unlocked ? (
                <>
                  <Check width={12} height={12} className="text-phos-400" />
                  read to the end · {progress}%
                </>
              ) : (
                <>
                  <Warn width={12} height={12} className="text-amber-400" />
                  {progress}% read · acceptance locked
                </>
              )}
            </span>
            <span className="font-mono text-[10px] tracking-tight text-txt-3">8 clauses · 1.9 KB</span>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-[1fr_252px] gap-3">
        <Card className="flex items-center gap-3 p-3.5">
          <button
            type="button"
            role="checkbox"
            aria-checked={accepted}
            aria-disabled={!unlocked}
            disabled={!unlocked}
            onClick={() => onAccept(!accepted)}
            className={cn(
              "flex items-center gap-3 rounded-[10px] border px-3 py-2.5 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
              accepted ? "border-phos-500/40 bg-phos-900/45" : "border-white/[0.09] bg-white/[0.02] hover:border-white/16",
              !unlocked && "cursor-default opacity-40",
            )}
          >
            <span
              className={cn(
                "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-all",
                accepted ? "border-phos-500 bg-phos-500 text-obsidian" : "border-white/20 text-transparent",
              )}
            >
              <Check width={12} height={12} className={accepted ? "draw-check" : ""} />
            </span>
            <span>
              <span className={cn("block font-display text-[13px] font-semibold tracking-tight", accepted ? "text-txt-1" : "text-txt-2")}>
                I accept the licence agreement
              </span>
              <span className="mt-0.5 block font-mono text-[10.5px] tracking-tight text-txt-3">
                {unlocked ? "recorded locally · no acceptance is transmitted" : "requires a full read of the document above"}
              </span>
            </span>
          </button>
        </Card>

        <Notice
          tone="amber"
          icon={<Warn width={15} height={15} />}
          title="Administrator rights"
          action={<span className="label-micro">policy note</span>}
        >
          Setup requests elevation at <span className="text-amber-300">finalize</span> to write Program Files + registry. Choose a user-scope path to skip
          UAC entirely.
        </Notice>
      </div>
    </div>
  );
}
