import { Card, Chip, MicroLabel, OptionRow, Stat } from "../components/ui";
import { Check, Folder, Key, Link, Lock, Terminal, Warn } from "../components/Icons";
import type { ComponentFlags } from "../lib/installer";

const CORE_MB = 386.6;

export function Components({
  components,
  setComponents,
  avBlock,
}: {
  components: ComponentFlags;
  setComponents: (c: ComponentFlags) => void;
  avBlock: boolean;
}) {
  const extras =
    (components.shortcut ? 0.002 : 0) + (components.pathEntry ? 0.0001 : 0) + (components.contextMenu ? 0.004 : 0);
  const total = CORE_MB + extras + 26.1;

  const toggle = (k: keyof ComponentFlags) => setComponents({ ...components, [k]: !components[k] });

  return (
    <div className="scroll-thin min-h-0 flex-1 overflow-y-auto pr-1">
      <div className="space-y-2.5">
        <OptionRow
          locked
          checked
          title="KAEL core console"
          desc="kael.exe, native runtime, app.asar bundle and the uninstaller. Required — repair and removal entries depend on it."
          meta="386.6 MB"
          icon={<Lock width={14} height={14} />}
        />

        <OptionRow
          checked={components.shortcut}
          onToggle={() => toggle("shortcut")}
          title="Desktop & Start menu shortcut"
          desc="Shell links created for all users. Removed cleanly on uninstall."
          meta="2 KB"
          icon={<Folder width={14} height={14} />}
        />

        <OptionRow
          checked={components.pathEntry}
          onToggle={() => toggle("pathEntry")}
          title="Add KAEL\bin to PATH"
          desc="Lets you launch `kael` from any terminal. Only new sessions see the change."
          meta="0.1 KB"
          icon={<Terminal width={14} height={14} />}
        />

        <OptionRow
          checked={components.contextMenu}
          onToggle={() => toggle("contextMenu")}
          title="Explorer context-menu: “Open in KAEL”"
          desc="Adds a shell verb for files and folders. Restart Explorer to see it immediately."
          meta="4 KB"
          icon={<Link width={14} height={14} />}
        />

        <div className="grid grid-cols-[1fr_236px] gap-3.5 pt-1">
          <Card className="p-3.5">
            <div className="flex items-center gap-2">
              <MicroLabel>footprint of this selection</MicroLabel>
              <span className="h-px flex-1 bg-white/[0.08]" />
              <span className="font-mono text-[10px] tracking-tight text-txt-3">recalculated live</span>
            </div>
            <div className="mt-2.5 flex items-end gap-4">
              <div>
                <div className="font-mono text-[26px] font-bold leading-none tracking-[-0.03em] text-phos-200 tnum">
                  {total.toFixed(1)}
                  <span className="ml-1.5 text-[12px] font-medium text-txt-3">MB</span>
                </div>
                <p className="mt-1.5 font-mono text-[10.5px] tracking-tight text-txt-3">
                  includes 26.1 MB offline glyph & theme packs
                </p>
              </div>
              <div className="ml-auto min-w-[168px]">
                <Stat k="extras selected" v={`${(extras * 1024).toFixed(1)} KB`} />
                <Stat k="registry keys" v={components.contextMenu ? "7" : "6"} />
                <Stat k="shell links" v={components.shortcut ? "2" : "0"} />
              </div>
            </div>
          </Card>

          <div className="space-y-2.5">
            <Card className="p-3.5">
              <MicroLabel>keyboard</MicroLabel>
              <div className="mt-2.5 space-y-2 font-mono text-[10.5px] tracking-tight text-txt-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-txt-3">toggle row</span>
                  <span className="flex gap-1">
                    <kbd className="rounded-[5px] border border-white/12 bg-white/[0.05] px-1.5 py-[1px] text-[9.5px] text-txt-2">Space</kbd>
                    <kbd className="rounded-[5px] border border-white/12 bg-white/[0.05] px-1.5 py-[1px] text-[9.5px] text-txt-2">Enter</kbd>
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-txt-3">move between rows</span>
                  <span className="flex gap-1">
                    <kbd className="rounded-[5px] border border-white/12 bg-white/[0.05] px-1.5 py-[1px] text-[9.5px] text-txt-2">Tab</kbd>
                    <kbd className="rounded-[5px] border border-white/12 bg-white/[0.05] px-1.5 py-[1px] text-[9.5px] text-txt-2">⇧Tab</kbd>
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-txt-3">locked row</span>
                  <Chip tone="dusk">required</Chip>
                </div>
              </div>
            </Card>

            {avBlock ? (
              <div className="flex items-start gap-2.5 rounded-card border border-amber-400/30 bg-amber-400/[0.05] px-3 py-2.5">
                <Warn width={14} height={14} className="mt-[1px] shrink-0 text-amber-400" />
                <p className="font-mono text-[10.5px] leading-[16px] text-amber-300/90">
                  Context-menu integration registers a shell verb — some AV suites flag HKCR writes. Setup falls back to a per-user verb if the machine-wide
                  key is blocked.
                </p>
              </div>
            ) : (
              <div className="flex items-start gap-2.5 rounded-card border border-white/[0.08] bg-white/[0.02] px-3 py-2.5">
                <Key width={14} height={14} className="mt-[1px] shrink-0 text-phos-400/80" />
                <p className="font-mono text-[10.5px] leading-[16px] text-txt-3">
                  Every selection is written into the removal manifest, so uninstall reverses exactly what you ticked here.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2.5 rounded-card border border-phos-500/25 bg-phos-900/25 px-3.5 py-2.5">
          <Check width={14} height={14} className="shrink-0 text-phos-400" />
          <p className="font-mono text-[10.5px] leading-[16px] text-txt-2">
            Install manifest will record: <span className="text-phos-300">
              {[
                "core",
                components.shortcut && "shell-links",
                components.pathEntry && "path",
                components.contextMenu && "shell-verb",
              ]
                .filter(Boolean)
                .join(" · ")}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
