import { useMemo } from "react";
import { cn } from "../utils/cn";
import { Button, Card, Chip, LogFeed, MicroLabel, Notice, PhaseStepper, Stat, Tooltip } from "../components/ui";
import { Check, Copy, Err, Retry, Shield, Terminal, Warn, ChevronDown } from "../components/Icons";
import {
  fmtClock,
  logToText,
  type EngineStatus,
  type LogEntry,
  type PhaseId,
} from "../lib/installer";

const PHASES: PhaseId[] = ["verify", "extract", "finalize"];
const LABELS_INSTALL: Record<PhaseId, string> = { verify: "verify", extract: "extract", finalize: "finalize" };
const LABELS_UNINSTALL: Record<PhaseId, string> = { verify: "pre-flight", extract: "remove", finalize: "cleanup" };

const TOTAL_OBJECTS = 3412;
const TOTAL_MB = 412.7;

export function Installing({
  status,
  pct,
  logs,
  elapsedMs,
  phase,
  variant,
  targetPath,
  onCancel,
  onRetry,
  onCopyLog,
  onShowFailureLog,
  showFailureLog,
}: {
  status: EngineStatus;
  pct: number;
  logs: LogEntry[];
  elapsedMs: number;
  phase: PhaseId;
  variant: "install" | "uninstall";
  targetPath: string;
  onCancel: () => void;
  onRetry: () => void;
  onCopyLog: () => void;
  onShowFailureLog: (v: boolean) => void;
  showFailureLog: boolean;
}) {
  const labels = variant === "install" ? LABELS_INSTALL : LABELS_UNINSTALL;
  const running = status === "running";
  const failed = status === "failed";
  const rolling = status === "rolling-back";
  const done = status === "done";

  const displayPct = pct;

  const errors = useMemo(() => logs.filter((l) => l.level === "err"), [logs]);
  const lastLine = logs[logs.length - 1];

  const eta = useMemo(() => {
    if (!running || pct < 2) return "—";
    return fmtClock((elapsedMs / pct) * (100 - pct));
  }, [running, pct, elapsedMs]);

  const throughput = useMemo(() => {
    if (elapsedMs < 800 || pct < 2) return "—";
    const mb = (pct / 100) * TOTAL_MB;
    return `${(mb / (elapsedMs / 1000)).toFixed(1)} MB/s`;
  }, [pct, elapsedMs]);

  const objectsDone = Math.round((pct / 100) * TOTAL_OBJECTS);

  const headline = failed
    ? "Installation failed"
    : rolling
      ? "Rolling back — no changes kept"
      : done
        ? variant === "install"
          ? "Finalising…"
          : "Finalising removal…"
        : variant === "install"
          ? "Installing KAEL 1.0.5"
          : "Removing KAEL 1.0.5";

  const phaseNote = {
    verify: variant === "install" ? "verifying payload & signature" : "checking for held handles",
    extract: variant === "install" ? "extracting to disk" : "removing files from disk",
    finalize: variant === "install" ? "registry · protocol · shortcuts" : "registry · shortcuts · cleanup",
  }[phase];

  return (
    <div className="scroll-thin flex min-h-0 flex-1 flex-col gap-3.5 overflow-y-auto pr-1">
      {/* ------------------------------------------------------------- header */}
      <div className="flex items-start gap-4">
        <div className="flex min-w-0 flex-1 flex-col gap-2.5">
          <div className="flex items-center gap-3">
            <span
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] border",
                failed
                  ? "border-alert-400/40 bg-alert-900/70 text-alert-400"
                  : rolling
                    ? "border-amber-400/40 bg-amber-400/10 text-amber-300"
                    : "border-phos-500/35 bg-phos-900/60 text-phos-300",
              )}
            >
              {failed ? (
                <Err width={16} height={16} />
              ) : rolling ? (
                <Warn width={16} height={16} />
              ) : done ? (
                <Shield width={16} height={16} />
              ) : (
                <Terminal width={16} height={16} />
              )}
            </span>
            <div className="min-w-0">
              <div className="flex items-baseline gap-2">
                <h2 className="font-display text-[15.5px] font-semibold tracking-tight text-txt-1">{headline}</h2>
                {running ? <span className="caret h-[14px] w-[8px] text-phos-500" /> : null}
              </div>
              <p className="mt-0.5 flex items-center gap-2 font-mono text-[10.5px] tracking-tight text-txt-3">
                <i
                  className={cn(
                    "h-[6px] w-[6px] rounded-full",
                    failed ? "bg-alert-400" : rolling ? "bg-amber-400" : running ? "light-pulse bg-phos-400" : "bg-phos-400",
                  )}
                />
                {failed ? "stopped at " + pct.toFixed(0) + "% — waiting for operator" : rolling ? "reverting partial changes" : `${phaseNote} · ${objectsDone.toLocaleString()} / ${TOTAL_OBJECTS.toLocaleString()} objects`}
              </p>
            </div>
          </div>

          {/* percentage + bar */}
          <div className="flex items-end gap-4">
            <div className="w-[104px] shrink-0">
              <div
                className={cn(
                  "font-mono text-[34px] font-bold leading-none tracking-[-0.04em] tnum",
                  failed ? "text-alert-400" : rolling ? "text-amber-300" : "text-phos-200",
                )}
              >
                {displayPct.toFixed(1)}
                <span className="ml-0.5 text-[15px] font-medium text-txt-3">%</span>
              </div>
            </div>

            <div className="min-w-0 flex-1">
              <div className="relative h-[8px] overflow-hidden rounded-full border border-white/[0.09] bg-black/60">
                {/* phase segment ticks */}
                {[12, 80].map((edge) => (
                  <span key={edge} className="absolute inset-y-0 z-20 w-px bg-black/80" style={{ left: `${edge}%` }} />
                ))}
                <div
                  className={cn(
                    "relative h-full overflow-hidden rounded-full transition-[width] duration-100 ease-linear",
                    failed ? "bg-gradient-to-r from-alert-900 to-alert-400" : rolling ? "stripes" : "bg-gradient-to-r from-phos-600 via-phos-500 to-phos-300 shadow-[0_0_20px_-2px_rgb(61_220_100/0.65)]",
                  )}
                  style={{ width: `${Math.max(displayPct, 1.2)}%` }}
                >
                  {running && variant === "install" ? <span className="shimmer absolute inset-0 overflow-hidden opacity-60" /> : null}
                </div>
              </div>

              <div className="mt-2 flex items-center gap-2 font-mono text-[10.5px] tracking-tight text-txt-3">
                <span className="text-phos-400/90">▸</span>
                <Tooltip text={lastLine?.text ?? "…"} side="bottom" className="min-w-0 flex-1">
                  <span className="block w-full truncate text-txt-2">{lastLine?.text ?? "…"}</span>
                </Tooltip>
                {rolling ? <span className="shrink-0 text-amber-300">safe rollback</span> : null}
              </div>
            </div>
          </div>
        </div>

        <div className="flex shrink-0 flex-col items-end gap-2.5">
          <PhaseStepper phases={PHASES} activePhase={phase} labels={labels} done={done} />
          <div className="flex items-center gap-2">
            <Chip tone={failed ? "err" : rolling ? "amber" : "phos"}>
              {failed ? "halting" : rolling ? "rollback" : running ? "in progress" : done ? "complete" : "idle"}
            </Chip>
            <Tooltip text={`${targetPath}\\kael.exe`}>
              <span className="max-w-[168px] truncate font-mono text-[10px] tracking-tight text-txt-3">{targetPath}</span>
            </Tooltip>
          </div>
        </div>
      </div>

      {/* --------------------------------------------------------------- stats */}
      <Card className="grid grid-cols-4 gap-x-4 px-3.5 py-2.5">
        <Stat k="elapsed" v={<span className="text-phos-300">{fmtClock(elapsedMs)}</span>} />
        <Stat k="remaining (est.)" v={failed || rolling ? "—" : eta} />
        <Stat k="throughput" v={failed || rolling ? "—" : throughput} />
        <Stat k="log" v={`${logs.length} lines`} />
      </Card>

      {/* -------------------------------------------------------------- log feed */}
      <LogFeed
        logs={logs}
        running={running || rolling}
        className="min-h-[188px] flex-1"
        label={variant === "install" ? "stdout · kael-setup.log" : "stdout · kael-uninstall.log"}
      />

      {/* ------------------------------------------------------------ failure UI */}
      {failed ? (
        <Notice
          tone="err"
          icon={<Err width={15} height={15} />}
          title={`Install failed at ${pct.toFixed(0)}% — ERROR 0x80070005 (access denied) while writing kael.exe`}
          action={
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" icon={<Copy width={12} height={12} />} onClick={onCopyLog}>
                copy log
              </Button>
              <Button size="sm" variant="primary" icon={<Retry width={12} height={12} />} onClick={onRetry}>
                retry
              </Button>
            </div>
          }
        >
          A locked handle or real-time scan blocked the final binary write. Nothing outside the staging folder was modified.
          <div className="mt-2.5">
            <button
              type="button"
              onClick={() => onShowFailureLog(!showFailureLog)}
              aria-expanded={showFailureLog}
              className="flex items-center gap-2 rounded-[8px] border border-alert-400/30 bg-alert-900/50 px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-alert-400 transition hover:bg-alert-900"
            >
              <ChevronDown width={12} height={12} className={cn("transition-transform duration-200", showFailureLog && "rotate-180")} />
              {showFailureLog ? "hide error detail" : `expand error log (${errors.length + 6} lines)`}
            </button>
            {showFailureLog ? (
              <pre className="scroll-thin anim-step mt-2.5 max-h-[122px] overflow-auto rounded-[10px] border border-alert-400/25 bg-black/60 p-3 font-mono text-[10.5px] leading-[17px] text-alert-400/90">
{`[cleanup] rollback snapshot taken: HKLM\\SOFTWARE\\KAEL (7 keys)
[cleanup] staging dir %TEMP%\\kael-0001 staged 214.1 MB — left in place for retry
${errors.map((e) => e.text).join("\n")}
[cleanup] WinError 5 :: CreateFileW(C:\\Program Files\\KAEL\\bin\\kael.exe)
[cleanup] possible holders: MsMpEng.exe (defender), kael.exe (pid 1184?)
[cleanup] audit log: %TEMP%\\kael-setup-1752.log`}
              </pre>
            ) : null}
          </div>
        </Notice>
      ) : null}

      {rolling ? (
        <Notice tone="amber" icon={<Warn width={15} height={15} />} title="Rollback in progress — do not close setup">
          The staged payload and registry snapshot are being reverted. When this finishes you return to the components step with the system unchanged.
        </Notice>
      ) : null}

      {/* footer-of-panel actions */}
      <div className="flex items-center gap-3">
        <MicroLabel className="shrink-0">
          {failed ? "operator action" : running ? "cancel is always safe" : "wrapping up"}
        </MicroLabel>
        <span className="h-px flex-1 bg-white/[0.07]" />
        {running || rolling ? (
          <Button size="sm" variant="quiet" onClick={onCancel} disabled={rolling}>
            cancel install
          </Button>
        ) : failed ? (
          <Button size="sm" variant="quiet" onClick={onShowFailureLog.bind(null, !showFailureLog)}>
            view audit trail
          </Button>
        ) : (
          <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-phos-300">
            <Check width={12} height={12} /> no residue
          </span>
        )}
      </div>
    </div>
  );
}

export function copyLogToClipboard(logs: LogEntry[], header: string[]) {
  const text = logToText(logs, header);
  navigator.clipboard?.writeText(text);
  return text;
}
