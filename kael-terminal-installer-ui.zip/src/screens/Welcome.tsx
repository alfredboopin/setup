import { useEffect, useState } from "react";
import { Chip, MicroLabel, Stat, Button, Card, Tooltip } from "../components/ui";
import { Rocket, Shield, Spark, Terminal, Book, ChevronRight } from "../components/Icons";

function useTyped(text: string, speed = 42, delay = 0) {
  const [n, setN] = useState(0);
  const [go, setGo] = useState(delay === 0);
  useEffect(() => {
    const t = window.setTimeout(() => setGo(true), delay);
    return () => window.clearTimeout(t);
  }, [delay]);
  useEffect(() => {
    if (!go) return;
    if (n >= text.length) return;
    const t = window.setTimeout(() => setN((v) => v + 1), speed);
    return () => window.clearTimeout(t);
  }, [go, n, text, speed]);
  return { text: text.slice(0, n), done: n >= text.length };
}

const BOOT_LINES = [
  "[ OK ] glyph map loaded — 168 operators registered",
  "[ OK ] presets: vim, emacs, fish · keychain bridge ready",
  "[ OK ] staging 3,412 objects · 412.7 MB payload",
  "[ OK ] installer signed · SHA-256 verified offline",
];

export function Welcome({ onInstall, onReleaseNotes }: { onInstall: () => void; onReleaseNotes: () => void }) {
  const head = useTyped("KAEL", 150, 260);
  const sub = useTyped("system console for operators who live in the terminal.", 16, 1150);
  const [booted, setBooted] = useState(0);

  useEffect(() => {
    if (!sub.done) return;
    const t = window.setInterval(() => setBooted((v) => (v >= BOOT_LINES.length ? v : v + 1)), 420);
    return () => window.clearInterval(t);
  }, [sub.done]);

  return (
    <div className="grid min-h-0 flex-1 grid-cols-[1fr_248px] gap-5">
      {/* ------------------------------------------------------------- splash */}
      <div className="flex min-h-0 flex-col">
        <div className="relative flex-1">
          <div className="pointer-events-none absolute -left-6 top-6 h-56 w-56 rounded-full bg-phos-500/[0.07] blur-[70px]" />
          <div className="relative pt-7">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[12px] text-phos-400">kael@setup</span>
              <span className="font-mono text-[12px] text-txt-3">:</span>
              <span className="font-mono text-[12px] text-amber-300">~</span>
              <span className="font-mono text-[12px] text-txt-3">$ ./kael-setup.exe --wizard</span>
            </div>

            <h1 className="mt-5 flex items-baseline font-mono text-[42px] font-bold leading-none tracking-[-0.03em] text-phos-200 drop-shadow-[0_0_28px_rgb(61_220_100/0.25)]">
              {head.text}
              {!head.done ? <span className="caret ml-2 h-[34px] w-[13px] text-phos-400" /> : null}
            </h1>

            <p className="mt-3 max-w-[520px] font-display text-[15px] leading-[24px] text-txt-2">
              {sub.text}
              {sub.done ? null : <span className="caret ml-0.5 h-[15px] w-[8px] align-[-2px] text-txt-3" />}
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Chip tone="phos">v1.0.5</Chip>
              <Chip>x64 · offline</Chip>
              <Chip>win 10 1809+ / 11</Chip>
            </div>

            <ul className="mt-6 min-h-[112px] space-y-1.5">
              {BOOT_LINES.map((l, i) => (
                <li
                  key={l}
                  className={`flex items-center gap-2 font-mono text-[11px] tracking-tight transition-all duration-300 ease-[var(--ease-out-kael)] ${
                    i < booted ? "translate-y-0 text-txt-2 opacity-100" : "translate-y-1 text-txt-3 opacity-0"
                  }`}
                >
                  <span className="text-phos-400">▸</span>
                  <span className={l.startsWith("[ OK ]") ? "text-phos-300/90" : ""}>{l}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <Button
            size="lg"
            variant="primary"
            icon={<Rocket width={15} height={15} />}
            iconRight={<ChevronRight width={14} height={14} />}
            onClick={onInstall}
            className="pl-5"
          >
            Install KAEL
          </Button>
          <Button size="lg" variant="ghost" icon={<Book width={14} height={14} />} onClick={onReleaseNotes}>
            Release notes
          </Button>
          <span className="ml-auto flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-txt-3">
            <Shield width={13} height={13} className="text-phos-500/80" />
            signed · kael systems ltd
          </span>
        </div>
      </div>

      {/* ------------------------------------------------------------ Readiness */}
      <div className="flex min-h-0 flex-col gap-4 pt-7">
        <Card className="p-4">
          <MicroLabel>readiness report</MicroLabel>
          <div className="mt-3">
            <Stat k="install size" v="412.7 MB" />
            <Stat k="free required" v="≥ 1.10 GB" />
            <Stat k="webview2" v="1.0.2903.40 · present" tone="phos" />
            <Stat k="arch" v="x64 native" />
            <Stat k="elevation" v="requested at finalize" />
            <Stat k="network calls" v="0 · fully offline" tone="phos" />
          </div>
        </Card>

        <Card className="p-4">
          <MicroLabel>will install</MicroLabel>
          <div className="mt-3 space-y-2 font-mono text-[11px] tracking-tight">
            <div className="flex items-center gap-2 text-txt-2">
              <Terminal width={13} height={13} className="text-phos-400/80" /> kael.exe + native runtime
            </div>
            <div className="flex items-center gap-2 text-txt-2">
              <Spark width={13} height={13} className="text-amber-300/80" /> 3 bundled themes · glyph pack
            </div>
            <div className="flex items-center gap-2 text-txt-3">
              <Shield width={13} height={13} /> uninstaller + repair entry
            </div>
          </div>
          <div className="mt-3.5 border-t border-white/[0.07] pt-3">
            <Tooltip text="C:\Program Files\KAEL\resources\app.asar" side="top">
              <span className="block w-full truncate font-mono text-[10.5px] tracking-tight text-txt-3">
                default target: C:\Program Files\KAEL\…
              </span>
            </Tooltip>
          </div>
        </Card>
      </div>
    </div>
  );
}
