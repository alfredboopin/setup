import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Button, Card, Chip, MicroLabel, Meter, Notice, Stat, Tooltip } from "../components/ui";
import { Check, Disk, Folder, Warn, Shield, ChevronRight, Key } from "../components/Icons";

const SIZE_ROWS = [
  { k: "kael.exe + native runtime", mb: 118.2, note: "signed, D3D11" },
  { k: "resources/app.asar", mb: 268.4, note: "core console bundle" },
  { k: "glyphs · themes · keybindings", mb: 26.1, note: "offline packs" },
  { k: "SQLite session store", mb: 2.0, note: "local only" },
  { k: "manifest · shell links", mb: 0.02, note: "32 objects" },
];

export const REQUIRED_MB = 412.7;
export const SCRATCH_MB = 180;
const TOTAL_LEGACY_MB = 132.6;

const PRESETS = [
  { label: "Program Files", path: "C:\\Program Files\\KAEL", tag: "needs UAC", elevated: true },
  { label: "User scope", path: "C:\\Users\\op\\AppData\\Local\\Programs\\KAEL", tag: "no UAC", elevated: false },
  { label: "Secondary volume", path: "D:\\Apps\\KAEL", tag: "cold storage", elevated: false },
];

export type PathStatus = {
  ok: boolean;
  level: "ok" | "warn" | "err";
  message: string;
  freeMb: number;
};

export function validatePath(p: string, lowDisk: boolean): PathStatus {
  const free = lowDisk ? 180 : 2164 * 1024;
  const trimmed = p.trim();
  if (!trimmed) return { ok: false, level: "err", message: "destination path is required", freeMb: free };
  const absolute = /^[A-Za-z]:\\/.test(trimmed) || trimmed.startsWith("\\\\");
  if (!absolute) return { ok: false, level: "err", message: "must be absolute — e.g. C:\\Program Files\\KAEL or \\\\host\\share", freeMb: free };
  if (/[<>:"|?*]/.test(trimmed.replace(/^[A-Za-z]:/, "")))
    return { ok: false, level: "err", message: "illegal character in path segment", freeMb: free };
  if (/^[A-Za-z]:\\?$/.test(trimmed)) return { ok: false, level: "err", message: "select a folder, not a drive root", freeMb: free };
  if (/^\\\\$/.test(trimmed)) return { ok: false, level: "err", message: "UNC path is incomplete", freeMb: free };
  if (/\\temp\\|\\tmp\\|\$Recycle/i.test(trimmed))
    return { ok: false, level: "err", message: "temporary directories are purged by policy — choose a stable target", freeMb: free };
  if (/^[A-Za-z]:\\Windows/i.test(trimmed))
    return { ok: false, level: "err", message: "targets a protected system directory", freeMb: free };
  if (free < REQUIRED_MB + SCRATCH_MB)
    return { ok: false, level: "warn", message: `only ${free} MB free — setup needs ${REQUIRED_MB} MB plus ${SCRATCH_MB} MB scratch`, freeMb: free };
  return { ok: true, level: "ok", message: "path writable · trailing folder will be created", freeMb: free };
}

export function Location({
  path,
  setPath,
  lowDisk,
  upgrade,
  preserveSettings,
  setPreserveSettings,
  avBlock,
  onValidity,
  onJumpToPath,
}: {
  path: string;
  setPath: (v: string) => void;
  lowDisk: boolean;
  upgrade: boolean;
  preserveSettings: boolean;
  setPreserveSettings: (v: boolean) => void;
  avBlock: boolean;
  onValidity: (s: PathStatus) => void;
  onJumpToPath: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [touched, setTouched] = useState(false);
  const status = useMemo(() => validatePath(path, lowDisk), [path, lowDisk]);

  useEffect(() => {
    onValidity(status);
  }, [status, onValidity]);

  const shortfall = Math.max(0, REQUIRED_MB + SCRATCH_MB - status.freeMb);
  const existing = upgrade && path.startsWith("C:\\Program Files");

  return (
    <div className="scroll-thin min-h-0 flex-1 overflow-y-auto pr-1">
      <div className="space-y-3.5">
        {/* --------------------------------------------------------- path input */}
        <Card className="p-3.5">
          <div className="flex items-center gap-2">
            <MicroLabel>destination folder</MicroLabel>
            <span className="h-px flex-1 bg-white/[0.08]" />
            <button
              type="button"
              onClick={() => {
                setPath("C:\\Program Files\\KAEL");
                setTouched(true);
                inputRef.current?.focus();
              }}
              className="font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3 transition hover:text-phos-300"
            >
              reset to default
            </button>
          </div>

          <label className="mt-3 flex items-stretch gap-2">
            <span className="sr-only">Install location</span>
            <span
              className={cn(
                "flex h-10 min-w-0 flex-1 items-center gap-2.5 rounded-[10px] border bg-black/50 px-3 transition-colors duration-150 ease-[var(--ease-out-kael)]",
                status.level === "ok" && "border-white/[0.09] focus-within:border-phos-500/60",
                status.level === "warn" && "border-amber-400/45",
                status.level === "err" && touched && "border-alert-400/45",
              )}
            >
              <Disk width={15} height={15} className="shrink-0 text-txt-3" />
              <input
                ref={inputRef}
                value={path}
                spellCheck={false}
                autoComplete="off"
                onChange={(e) => {
                  setPath(e.target.value);
                  setTouched(true);
                }}
                aria-invalid={!status.ok}
                aria-describedby="path-validation"
                className="min-w-0 flex-1 bg-transparent font-mono text-[12px] tracking-tight text-txt-1 outline-none placeholder:text-txt-3/70"
                placeholder="C:\Program Files\KAEL"
              />
              {status.ok ? (
                <Check width={14} height={14} className="shrink-0 text-phos-400 draw-check" />
              ) : (
                <Warn width={14} height={14} className={cn("shrink-0", status.level === "warn" ? "text-amber-400" : "text-alert-400")} />
              )}
            </span>

            <Button
              variant="ghost"
              icon={<Folder width={14} height={14} />}
              onClick={() => {
                setPath("D:\\Apps\\KAEL");
                setTouched(true);
              }}
              className="h-10"
            >
              Browse…
            </Button>
          </label>

          <div id="path-validation" className="mt-2 flex items-center gap-2 font-mono text-[10.5px] tracking-tight" role="status">
            <span
              className={cn(
                status.ok ? "text-phos-400" : status.level === "warn" ? "text-amber-300" : "text-alert-400",
                !touched && !status.ok && status.level === "err" && "text-txt-3",
              )}
            >
              {touched || status.level !== "err" ? status.message : "awaiting a valid absolute path"}
            </span>
            <span className="flex-1" />
            <span className="text-txt-3">{path.length} chars</span>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            {PRESETS.map((p) => (
              <button
                key={p.path}
                type="button"
                onClick={() => {
                  setPath(p.path);
                  setTouched(true);
                }}
                aria-pressed={path === p.path}
                className={cn(
                  "group flex items-center gap-2 rounded-full border px-2.5 py-[5px] transition-all duration-150 ease-[var(--ease-out-kael)]",
                  path === p.path
                    ? "border-phos-500/40 bg-phos-500/10"
                    : "border-white/[0.08] bg-white/[0.02] hover:border-white/16 hover:bg-white/[0.05]",
                )}
              >
                <span className={cn("font-mono text-[10.5px] tracking-tight", path === p.path ? "text-phos-200" : "text-txt-2")}>{p.label}</span>
                <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-txt-3">{p.tag}</span>
              </button>
            ))}
          </div>
        </Card>

        {/* --------------------------------------------------------------- space */}
        <div className="grid grid-cols-[1fr_236px] gap-3.5">
          <Card className="p-3.5">
            <div className="flex items-center gap-2">
              <MicroLabel>disk space meter</MicroLabel>
              <span className="h-px flex-1 bg-white/[0.08]" />
              <span className="font-mono text-[10px] tracking-tight text-txt-3">volume {path.slice(0, 2) || "C:"}</span>
            </div>
            <Meter className="mt-3" required={REQUIRED_MB} free={status.freeMb} available={status.ok} />
            <div className="mt-3 grid grid-cols-3 gap-3 border-t border-white/[0.07] pt-3">
              <Stat k="required" v={`${REQUIRED_MB} MB`} />
              <Stat k="scratch peak" v={`+${SCRATCH_MB} MB`} tone="amber" />
              <Stat k="after install" v={status.freeMb >= 1024 ? `${((status.freeMb - REQUIRED_MB) / 1024).toFixed(1)} GB free` : `${(status.freeMb - REQUIRED_MB).toFixed(0)} MB free`} />
            </div>
          </Card>

          <Card className="p-3.5">
            <MicroLabel>estimated install size</MicroLabel>
            <div className="mt-2.5 space-y-[3px]">
              {SIZE_ROWS.map((r) => (
                <div key={r.k} className="flex items-baseline justify-between gap-2">
                  <span className="min-w-0 truncate font-mono text-[10.5px] tracking-tight text-txt-2">{r.k}</span>
                  <span className="shrink-0 font-mono text-[10.5px] text-txt-3 tnum">{r.mb < 1 ? `${(r.mb * 1024).toFixed(0)} KB` : `${r.mb.toFixed(1)} MB`}</span>
                </div>
              ))}
            </div>
            <div className="mt-2.5 flex items-baseline justify-between border-t border-white/[0.07] pt-2.5">
              <span className="label-micro">total</span>
              <span className="font-mono text-[13px] font-semibold text-phos-300 tnum">{REQUIRED_MB} MB</span>
            </div>
            <p className="mt-1.5 font-mono text-[10px] leading-[15px] text-txt-3">
              legacy v1.0.5 footprint {TOTAL_LEGACY_MB} MB is replaced in place, not duplicated.
            </p>
          </Card>
        </div>

        {/* ------------------------------------------------------------- notices */}
        {!status.ok && status.level === "warn" ? (
          <Notice
            tone="amber"
            icon={<Disk width={15} height={15} />}
            title={`Not enough free space on ${path.slice(0, 2) || "C:"} — short by ${shortfall.toFixed(0)} MB`}
            action={
              <Button size="sm" variant="warn" onClick={onJumpToPath} icon={<ChevronRight width={12} height={12} />}>
                jump to path
              </Button>
            }
          >
            Setup will not begin until {REQUIRED_MB} MB + {SCRATCH_MB} MB scratch are available. Free space, choose the user scope preset (no elevation), or
            point the destination at a secondary volume.
          </Notice>
        ) : null}

        {existing ? (
          <Notice
            tone="phos"
            icon={<Check width={15} height={15} />}
            title="Existing install detected — KAEL v1.0.5 at this location"
            action={
              <button
                type="button"
                role="checkbox"
                aria-checked={preserveSettings}
                onClick={() => setPreserveSettings(!preserveSettings)}
                className={cn(
                  "flex items-center gap-2 rounded-[9px] border px-2.5 py-1.5 transition",
                  preserveSettings ? "border-phos-500/40 bg-phos-900/50" : "border-white/[0.09] bg-white/[0.02]",
                )}
              >
                <span
                  className={cn(
                    "grid h-[14px] w-[14px] place-items-center rounded-[4px] border",
                    preserveSettings ? "border-phos-500 bg-phos-500 text-obsidian" : "border-white/20 text-transparent",
                  )}
                >
                  <Check width={10} height={10} />
                </span>
                <span className="font-mono text-[10.5px] tracking-tight text-txt-2">preserve settings</span>
              </button>
            }
          >
            Settings from v1.0.5 detected at %APPDATA%\KAEL — they will be preserved: config.json (14.2 KB), sessions\ (1.1 MB), keybindings.kael (3.4 KB).
            Binaries are replaced, sessions are appended to.
          </Notice>
        ) : null}

        {avBlock ? (
          <Notice tone="amber" icon={<Shield width={15} height={15} />} title="Real-time protection is scanning this location">
            Defender's heuristic pass adds ~40 s to the extract phase and may hold a handle on kael-hook.dll. If setup reports 0x80070005, allow
            <span className="text-txt-1"> C:\Program Files\KAEL\ </span> in your AV exclusion list and retry — or install to the user scope, which needs no
            elevation.
          </Notice>
        ) : null}

        <Card className="flex items-center gap-3 p-3.5">
          <Key width={15} height={15} className="shrink-0 text-txt-3" />
          <div className="min-w-0 flex-1">
            <div className="font-mono text-[11px] tracking-tight text-txt-2">Resolved target</div>
            <Tooltip text={`${path}\\${path.endsWith("\\") ? "" : ""}kael.exe`} className="mt-1 block">
              <span className="block w-full truncate font-mono text-[10.5px] tracking-tight text-txt-3">
                {path}
                {path.endsWith("\\") ? "" : "\\"}kael.exe
              </span>
            </Tooltip>
          </div>
          <Chip tone="dusk">
            <span className="h-[5px] w-[5px] rounded-full bg-phos-400" /> NTFS · writable
          </Chip>
        </Card>
      </div>
    </div>
  );
}
