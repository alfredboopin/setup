import { cn } from "../utils/cn";
import { Button, Card, Chip, MicroLabel, Notice, Stat, Tooltip } from "../components/ui";
import { Check, Folder, Key, Link, Terminal, Trash, Warn, Shield, Lock } from "../components/Icons";

const REMOVAL = [
  { k: "kael.exe + native runtime", mb: "118.2 MB", icon: <Terminal width={13} height={13} /> },
  { k: "resources\\app.asar", mb: "268.4 MB", icon: <Folder width={13} height={13} /> },
  { k: "glyphs\\ · themes\\ · keybindings\\", mb: "26.1 MB", icon: <Key width={13} height={13} /> },
  { k: "registry — protocol, uninstall entry, verbs", mb: "6 keys", icon: <Link width={13} height={13} /> },
];

export function Uninstall({
  targetPath,
  keepSettings,
  setKeepSettings,
  installedMb,
}: {
  targetPath: string;
  keepSettings: boolean;
  setKeepSettings: (v: boolean) => void;
  installedMb: number;
}) {
  return (
    <div className="scroll-thin min-h-0 flex-1 overflow-y-auto pr-1">
      <div className="space-y-3.5">
        <div className="flex items-start gap-3">
          <span className="mt-[2px] grid h-9 w-9 shrink-0 place-items-center rounded-[11px] border border-amber-400/35 bg-amber-400/[0.08] text-amber-300">
            <Trash width={17} height={17} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2 className="font-display text-[16px] font-semibold tracking-tight text-txt-1">Remove KAEL 1.0.5</h2>
              <Chip tone="dusk">
                <span className="h-[5px] w-[5px] rounded-full bg-phos-400" /> installed
              </Chip>
            </div>
            <p className="mt-1 max-w-[520px] font-mono text-[11.5px] leading-[18px] text-txt-2">
              This removes the console, its runtime and every shell integration registered on this machine. The removal manifest lists exactly what was
              installed — nothing else on the volume is touched.
            </p>
          </div>
        </div>

        <Card className="p-3.5">
          <div className="flex items-center gap-2">
            <MicroLabel>will be deleted</MicroLabel>
            <span className="h-px flex-1 bg-white/[0.08]" />
            <span className="font-mono text-[10.5px] text-amber-300 tnum">{installedMb.toFixed(1)} MB reclaimed</span>
          </div>
          <div className="mt-3 space-y-2">
            {REMOVAL.map((r) => (
              <div key={r.k} className="flex items-center gap-2.5">
                <span className="shrink-0 text-txt-3">{r.icon}</span>
                <span className="min-w-0 flex-1 truncate font-mono text-[11px] tracking-tight text-txt-2">{r.k}</span>
                <span className="shrink-0 font-mono text-[10.5px] text-txt-3 tnum">{r.mb}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 border-t border-white/[0.07] pt-3">
            <Tooltip text={`${targetPath} · removal target`} className="block">
              <span className="block w-full truncate font-mono text-[10.5px] tracking-tight text-txt-3">{targetPath}</span>
            </Tooltip>
          </div>
        </Card>

        <div className="grid grid-cols-[1fr_252px] gap-3.5">
          <Card className="p-3.5">
            <MicroLabel>options</MicroLabel>
            <button
              type="button"
              role="checkbox"
              aria-checked={keepSettings}
              onClick={() => setKeepSettings(!keepSettings)}
              className={cn(
                "mt-3 flex w-full items-center gap-3 rounded-[10px] border px-3 py-2.5 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
                keepSettings ? "border-phos-500/35 bg-phos-900/40" : "border-alert-400/35 bg-alert-900/40",
              )}
            >
              <span
                className={cn(
                  "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-all",
                  keepSettings ? "border-phos-500 bg-phos-500 text-obsidian" : "border-white/20 text-transparent",
                )}
              >
                <Check width={12} height={12} className={keepSettings ? "draw-check" : ""} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-display text-[13px] font-semibold tracking-tight text-txt-1">
                  Keep settings & session history
                </span>
                <span className="mt-0.5 block font-mono text-[10.5px] leading-[16px] tracking-tight text-txt-3">
                  {keepSettings
                    ? "%APPDATA%\\KAEL retained (1.2 MB) — reinstalling restores your workspace instantly"
                    : "settings, sessions, keybindings and console history will be purged"}
                </span>
              </span>
            </button>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button
                size="sm"
                variant="danger"
                disabled={!keepSettings}
                onClick={() => setKeepSettings(false)}
                icon={<Trash width={12} height={12} />}
              >
                purge everything
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setKeepSettings(true)} icon={<Lock width={12} height={12} />}>
                keep my data
              </Button>
            </div>

            <div className="mt-3.5 flex items-center gap-3 border-t border-white/[0.07] pt-3.5">
              <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3">
                <Trash width={12} height={12} className="text-amber-400/80" />
                “uninstall kael” is the footer CTA — confirm there
              </span>
              <span className="ml-auto flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3">
                <span className="rounded-[4px] border border-white/12 bg-white/[0.04] px-1.5 py-[1px] text-[9.5px]">↵</span> continue
              </span>
            </div>
          </Card>

          <div className="space-y-3">
            <Card className="p-3.5">
              <MicroLabel>before you go</MicroLabel>
              <div className="mt-2.5">
                <Stat k="sessions stored" v="4 active" />
                <Stat k="theme packs" v="3 installed" />
                <Stat k="appdata used" v="1.2 MB" />
              </div>
            </Card>
            <Notice tone="amber" icon={<Shield width={15} height={15} />} title="Elevation required">
              Registry writes under HKLM need Administrator. If UAC is blocked by policy, setup falls back to a per-user uninstall and warns you.
            </Notice>
            <div className="flex items-start gap-2.5 rounded-card border border-white/[0.08] bg-white/[0.02] px-3 py-2.5">
              <Warn width={14} height={14} className="mt-[1px] shrink-0 text-amber-400/90" />
              <p className="font-mono text-[10.5px] leading-[16px] text-txt-3">
                Running instances hold file handles — setup stops kael.exe gracefully before removing binaries (unsaved console buffers are flushed to
                %TEMP%).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
