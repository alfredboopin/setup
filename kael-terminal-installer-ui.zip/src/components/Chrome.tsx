import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import { Glyph, WinClose, WinMin, NoiseTexture } from "./Icons";
import { IconButton } from "./ui";

/* ==================================================== desktop + window wash */
export function Backdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-obsidian" />
      {/* desktop ambience — faint phosphor bleed, no gradients-of-SaaS */}
      <div className="absolute -left-40 top-1/3 h-[520px] w-[520px] rounded-full bg-phos-500/[0.045] blur-[110px]" />
      <div className="absolute -right-32 -bottom-24 h-[420px] w-[420px] rounded-full bg-amber-400/[0.03] blur-[120px]" />
      <div className="tex-grid absolute inset-0 opacity-[0.55]" />
      <div className="tex-scan scan-drift absolute inset-0 opacity-60" />
      <NoiseTexture />
      <div className="vignette absolute inset-0" />
    </div>
  );
}

/* =========================================================== window chrome */
export function TitleBar({
  onMinimize,
  onClose,
  onDragStart,
  dragging,
  overlays,
}: {
  onMinimize: () => void;
  onClose: () => void;
  onDragStart: (e: React.PointerEvent) => void;
  dragging: boolean;
  overlays?: ReactNode;
}) {
  return (
    <div
      onPointerDown={onDragStart}
      className={cn(
        "relative z-20 flex h-[42px] shrink-0 select-none items-center gap-3 rounded-t-[15px] border-b border-white/[0.07] px-3.5",
        "bg-[linear-gradient(180deg,rgb(255,255,255/0.045),rgb(255,255,255/0.012))]",
        dragging ? "cursor-grabbing" : "cursor-grab",
      )}
    >
      <span className="flex items-center gap-2.5">
        <Glyph width={17} height={17} className="text-phos-400 drop-shadow-[0_0_10px_rgb(61_220_100/0.5)]" />
        <span className="font-mono text-[11.5px] font-medium tracking-tight text-txt-1">KAEL Setup</span>
        <span className="font-mono text-[10.5px] text-txt-3">v1.0.5</span>
      </span>

      <span className="mx-1 h-3.5 w-px bg-white/10" />
      <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-txt-3 sm:inline">
        x64 · offline · no network access
      </span>

      <span className="flex-1" />

      <span
        className="pointer-events-auto flex items-center gap-1"
        onPointerDown={(e) => e.stopPropagation()}
      >
        {overlays}
        <span className="mx-1.5 h-3.5 w-px bg-white/10" />
        <IconButton label="Minimize" onClick={onMinimize}>
          <WinMin width={14} height={14} />
        </IconButton>
        <IconButton
          label="Close"
          onClick={onClose}
          className="hover:bg-alert-400/15 hover:text-alert-400"
        >
          <WinClose width={14} height={14} />
        </IconButton>
      </span>
    </div>
  );
}

/* ============================================================= status strip */
export function StatusStrip({
  left,
  right,
  tone = "idle",
}: {
  left: ReactNode;
  right?: ReactNode;
  tone?: "idle" | "busy" | "warn" | "ok";
}) {
  const dot = {
    idle: "bg-white/25",
    busy: "light-pulse bg-phos-400",
    warn: "bg-amber-400",
    ok: "bg-phos-400",
  }[tone];
  return (
    <div className="flex h-[26px] shrink-0 items-center gap-3 rounded-b-[15px] border-t border-white/[0.07] bg-black/40 px-3.5">
      <span className={cn("h-[6px] w-[6px] shrink-0 rounded-full", dot)} />
      <span className="truncate font-mono text-[10px] tracking-tight text-txt-3">{left}</span>
      <span className="flex-1" />
      <span className="hidden shrink-0 font-mono text-[10px] tracking-tight text-txt-3 sm:inline">{right}</span>
    </div>
  );
}
