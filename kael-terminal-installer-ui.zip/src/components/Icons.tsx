import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

const base = (p: P) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...p,
});

/* ---------------------------------------------------------------- brand mark */
export const Glyph = (p: P) => (
  <svg viewBox="0 0 24 24" fill="none" aria-hidden {...p}>
    {/* bracket frame */}
    <path
      d="M7 3.25H4.6A1.35 1.35 0 0 0 3.25 4.6v4.2M17 3.25h2.4a1.35 1.35 0 0 1 1.35 1.35v4.2M20.75 15.2v4.2A1.35 1.35 0 0 1 19.4 20.75H17M7 20.75H4.6A1.35 1.35 0 0 1 3.25 19.4v-4.2"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
    />
    {/* prompt + cursor block */}
    <path d="M9.1 9.4 11.6 12l-2.5 2.6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="13.4" y="13.4" width="4.6" height="2.4" rx="0.5" fill="currentColor" />
    <rect x="13.4" y="8.6" width="4.6" height="2.4" rx="0.5" fill="currentColor" opacity="0.35" />
  </svg>
);

export const WinMin = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 12h12" />
  </svg>
);

export const WinClose = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 7l10 10M17 7L7 17" />
  </svg>
);

/* ------------------------------------------------------------------- status */
export const Check = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 12.8l4.2 4.2L19 7.4" strokeWidth="2" />
  </svg>
);

export const CheckCircle = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9" opacity="0.4" />
    <path d="M8 12.4l2.8 2.8L16.4 9.4" strokeWidth="1.8" />
  </svg>
);

export const Lock = (p: P) => (
  <svg {...base(p)}>
    <rect x="5" y="10.5" width="14" height="9.5" rx="2" />
    <path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" />
    <circle cx="12" cy="15.2" r="1.1" fill="currentColor" stroke="none" />
  </svg>
);

export const Warn = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 4.6l8.4 14.6H3.6L12 4.6z" />
    <path d="M12 10v4.2" />
    <circle cx="12" cy="16.9" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

export const Err = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.4" />
    <path d="M9.2 9.2l5.6 5.6M14.8 9.2l-5.6 5.6" />
  </svg>
);

export const Info = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.4" opacity="0.5" />
    <path d="M12 11v5.2" />
    <circle cx="12" cy="8.2" r="0.95" fill="currentColor" stroke="none" />
  </svg>
);

export const Shield = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3.4l7 2.4v5.4c0 4.4-2.9 7.7-7 9.4-4.1-1.7-7-5-7-9.4V5.8l7-2.4z" />
    <path d="M8.8 12l2.3 2.3 4.1-4.4" />
  </svg>
);

/* -------------------------------------------------------------------- objects */
export const Folder = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.6 7.4a1.8 1.8 0 0 1 1.8-1.8h3.4l1.7 2.1h7a1.8 1.8 0 0 1 1.8 1.8v7.7a1.8 1.8 0 0 1-1.8 1.8H5.4a1.8 1.8 0 0 1-1.8-1.8V7.4z" />
  </svg>
);

export const Disk = (p: P) => (
  <svg {...base(p)}>
    <ellipse cx="12" cy="6.6" rx="7.4" ry="2.9" />
    <path d="M4.6 6.6v10.8c0 1.6 3.3 2.9 7.4 2.9s7.4-1.3 7.4-2.9V6.6" />
    <path d="M4.6 12c0 1.6 3.3 2.9 7.4 2.9s7.4-1.3 7.4-2.9" />
  </svg>
);

export const Terminal = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2" />
    <path d="M7.4 10l2.3 2.2-2.3 2.3" />
    <path d="M12.4 14.8h4.2" />
  </svg>
);

export const Link = (p: P) => (
  <svg {...base(p)}>
    <path d="M10.2 13.8a3.4 3.4 0 0 0 4.9 0l2.4-2.4a3.5 3.5 0 0 0-4.9-4.9l-1 1" />
    <path d="M13.8 10.2a3.4 3.4 0 0 0-4.9 0l-2.4 2.4a3.5 3.5 0 0 0 4.9 4.9l1-1" />
  </svg>
);

export const Rocket = (p: P) => (
  <svg {...base(p)}>
    <path d="M13.6 4.6c3 .4 5.4 2.8 5.8 5.8-3.8 1-6.4 3.2-8 6.2l-1.4-1.4-2.8-2.8c3-1.6 5.2-4.2 6.4-7.8z" />
    <path d="M9.6 15.4 6 19M8 12.6l-2.6.8 1.4 1.4M11.4 16l-.8 2.6-1.4-1.4" />
  </svg>
);

export const Trash = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.8 6.6h14.4M9.4 6.6V4.9a1 1 0 0 1 1-1h3.2a1 1 0 0 1 1 1v1.7" />
    <path d="M6.6 6.6l.9 11.6a1.6 1.6 0 0 0 1.6 1.5h5.8a1.6 1.6 0 0 0 1.6-1.5l.9-11.6" />
    <path d="M10.6 10.4v6M13.4 10.4v6" />
  </svg>
);

export const Copy = (p: P) => (
  <svg {...base(p)}>
    <rect x="8.6" y="8.6" width="10.4" height="10.4" rx="2" />
    <path d="M15.4 8.6V6.8A1.8 1.8 0 0 0 13.6 5H6.8A1.8 1.8 0 0 0 5 6.8v6.8A1.8 1.8 0 0 0 6.8 15.4h1.8" />
  </svg>
);

export const Retry = (p: P) => (
  <svg {...base(p)}>
    <path d="M19 12a7 7 0 1 1-2.6-5.4" />
    <path d="M19.4 4.6v4.2h-4.2" />
  </svg>
);

export const ChevronRight = (p: P) => (
  <svg {...base(p)}>
    <path d="M9.6 6.4l5.6 5.6-5.6 5.6" />
  </svg>
);

export const ChevronLeft = (p: P) => (
  <svg {...base(p)}>
    <path d="M14.4 6.4L8.8 12l5.6 5.6" />
  </svg>
);

export const ChevronDown = (p: P) => (
  <svg {...base(p)}>
    <path d="M6.4 9.6L12 15.2l5.6-5.6" />
  </svg>
);

export const Key = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.4" y="7.4" width="17.2" height="9.2" rx="2" />
    <path d="M7 11h.01M10.4 11h.01M13.8 11h.01M17 11h.01M8 14h8" />
  </svg>
);

export const Sliders = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 7.6h6M14 7.6h5M5 16.4h5M13 16.4h6" />
    <circle cx="12.4" cy="7.6" r="2" />
    <circle cx="11.4" cy="16.4" r="2" />
  </svg>
);

export const Book = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.4 5.6A1.8 1.8 0 0 1 6.2 3.8h5v14.6H6.2a1.8 1.8 0 0 0-1.8 1.8V5.6z" />
    <path d="M19.6 5.6a1.8 1.8 0 0 0-1.8-1.8h-5v14.6h5a1.8 1.8 0 0 1 1.8 1.8V5.6z" />
  </svg>
);

export const Spark = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 4.4l1.7 4.6 4.6 1.7-4.6 1.7L12 17l-1.7-4.6L5.7 10.7l4.6-1.7L12 4.4z" />
    <path d="M18.4 15.6l.7 1.9 1.9.7-1.9.7-.7 1.9-.7-1.9-1.9-.7 1.9-.7.7-1.9z" opacity="0.6" />
  </svg>
);

/* ------------------------------------------------------------ textures (SVG) */
export const NoiseTexture = (p: P) => (
  <svg aria-hidden className="absolute inset-0 h-full w-full" {...p}>
    <filter id="kael-grain">
      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" stitchTiles="stitch" />
      <feColorMatrix type="saturate" values="0" />
    </filter>
    <rect width="100%" height="100%" filter="url(#kael-grain)" opacity="0.032" />
  </svg>
);

export const GridTexture = (p: P) => <svg aria-hidden className="absolute inset-0 h-full w-full tex-grid" {...p} />;
