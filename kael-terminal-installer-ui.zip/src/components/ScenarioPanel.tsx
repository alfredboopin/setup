import { useEffect, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { Warn, Shield, Sliders, Spark, Retry } from "./Icons";

export type ScenarioId = "clean" | "lowDisk" | "upgrade" | "avBlock" | "failure";

export const SCENARIOS: { id: ScenarioId; label: string; hint: string; icon: ReactNode; tone?: "amber" | "err" }[] = [
  { id: "clean", label: "Clean install", hint: "no pre-existing state · happy path", icon: <Spark width={14} height={14} /> },
  { id: "lowDisk", label: "Insufficient disk space", hint: "target volume has 180 MB free", icon: <Warn width={14} height={14} />, tone: "amber" },
  { id: "upgrade", label: "Upgrade over v1.0.5", hint: "settings detected & preserved", icon: <Retry width={14} height={14} /> },
  { id: "avBlock", label: "AV / policy interference", hint: "admin + real-time scan notes", icon: <Shield width={14} height={14} />, tone: "amber" },
  { id: "failure", label: "Failed install", hint: "error 0x80070005 mid-extract", icon: <Warn width={14} height={14} />, tone: "err" },
];

export function ScenarioPanel({
  open,
  scenario,
  setScenario,
  speed,
  setSpeed,
  onClose,
}: {
  open: boolean;
  scenario: ScenarioId;
  setScenario: (s: ScenarioId) => void;
  speed: number;
  setSpeed: (n: number) => void;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="anim-rise absolute right-3 top-[48px] z-30 w-[318px] rounded-glass border border-white/[0.1] bg-[#0b0f0d]/97 p-3 shadow-[0_40px_90px_-30px_rgb(0_0_0/0.95)] backdrop-blur-xl">
      <div className="flex items-center gap-2 px-1 pb-2">
        <Sliders width={14} height={14} className="text-phos-400" />
        <span className="font-display text-[12.5px] font-semibold tracking-tight text-txt-1">Preview scenarios</span>
        <span className="flex-1" />
        <span className="label-micro">demo only</span>
      </div>
      <p className="px-1 pb-2.5 font-mono text-[10px] leading-[15px] text-txt-3">
        Drives the designed edge-cases. Not present in the shipped bootstrapper.
      </p>

      <div className="space-y-1">
        {SCENARIOS.map((s) => {
          const active = scenario === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setScenario(s.id)}
              aria-pressed={active}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-[10px] border px-2.5 py-2 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
                active
                  ? s.tone === "err"
                    ? "border-alert-400/40 bg-alert-400/[0.08]"
                    : s.tone === "amber"
                      ? "border-amber-400/40 bg-amber-400/[0.07]"
                      : "border-phos-500/40 bg-phos-900/50"
                  : "border-white/[0.07] bg-white/[0.02] hover:border-white/16 hover:bg-white/[0.05]",
              )}
            >
              <span
                className={cn(
                  active
                    ? s.tone === "err"
                      ? "text-alert-400"
                      : s.tone === "amber"
                        ? "text-amber-300"
                        : "text-phos-300"
                    : "text-txt-3",
                )}
              >
                {s.icon}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-mono text-[11.5px] tracking-tight text-txt-1">{s.label}</span>
                <span className="block truncate font-mono text-[10px] tracking-tight text-txt-3">{s.hint}</span>
              </span>
              <span
                className={cn(
                  "h-[13px] w-[13px] shrink-0 rounded-full border",
                  active ? "border-phos-400 bg-phos-500/70 shadow-[0_0_12px_-1px_rgb(61_220_100/0.9)]" : "border-white/20",
                )}
              />
            </button>
          );
        })}
      </div>

      <div className="mt-3 flex items-center gap-2 border-t border-white/[0.08] pt-2.5">
        <span className="label-micro">sim speed</span>
        <span className="flex-1" />
        {[1, 2.5].map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSpeed(s)}
            aria-pressed={speed === s}
            className={cn(
              "rounded-full border px-2.5 py-[3px] font-mono text-[10px] uppercase tracking-[0.16em] transition",
              speed === s
                ? "border-phos-500/40 bg-phos-500/12 text-phos-300"
                : "border-white/10 bg-white/[0.02] text-txt-3 hover:text-txt-1",
            )}
          >
            {s}×
          </button>
        ))}
      </div>
    </div>
  );
}
