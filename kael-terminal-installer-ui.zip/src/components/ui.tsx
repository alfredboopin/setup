import {
  forwardRef,
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import { cn } from "../utils/cn";
import { Check, Copy, Lock, ChevronDown, Terminal } from "./Icons";
import type { LogEntry, PhaseId } from "../lib/installer";

/* ============================================================== micro-label */
export function MicroLabel({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("label-micro", className)}>{children}</div>;
}

/* ================================================================= buttons */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "warn" | "danger" | "quiet";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  iconRight?: ReactNode;
};

export const Button = forwardRef<HTMLButtonElement, BtnProps>(function Button(
  { variant = "ghost", size = "md", icon, iconRight, className, children, ...rest },
  ref,
) {
  const sizes = {
    sm: "h-7 px-3 text-[11px] gap-1.5 rounded-lg",
    md: "h-9 px-4 text-[12px] gap-2 rounded-[10px]",
    lg: "h-11 px-6 text-[13px] gap-2.5 rounded-xl",
  }[size];

  const variants = {
    primary:
      "bg-phos-500 text-obsidian font-semibold border border-transparent hover:shadow-glow hover:brightness-[1.06] active:brightness-95 active:shadow-none",
    ghost:
      "bg-white/[0.03] text-txt-2 border border-white/10 hover:text-txt-1 hover:bg-white/[0.07] hover:border-white/20 active:bg-white/[0.04] active:shadow-none",
    warn:
      "bg-amber-400/10 text-amber-300 border border-amber-400/35 hover:bg-amber-400/16 hover:border-amber-400/60 hover:shadow-glow-amber active:bg-amber-400/10",
    danger:
      "bg-alert-900/60 text-alert-400 border border-alert-400/35 hover:bg-alert-900 hover:border-alert-400/60 active:bg-alert-900/70",
    quiet:
      "text-txt-3 border border-transparent hover:text-phos-300 hover:bg-white/[0.05] active:bg-white/[0.02]",
  }[variant];

  return (
    <button
      ref={ref}
      className={cn(
        "group relative inline-flex select-none items-center justify-center whitespace-nowrap font-mono tracking-tight",
        "transition-[background-color,border-color,box-shadow,color,transform,filter] duration-150 ease-[var(--ease-out-kael)]",
        "hover:scale-[1.015] active:scale-[0.985]",
        "disabled:pointer-events-none disabled:opacity-40 disabled:hover:scale-100",
        sizes,
        variants,
        className,
      )}
      {...rest}
    >
      {icon ? <span className="shrink-0 opacity-90">{icon}</span> : null}
      {children}
      {iconRight ? <span className="shrink-0 opacity-70">{iconRight}</span> : null}
    </button>
  );
});

export function IconButton({
  label,
  active,
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string; active?: boolean; children: ReactNode }) {
  return (
    <button
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={cn(
        "grid h-7 w-7 place-items-center rounded-[7px] text-txt-3 transition-all duration-150 ease-[var(--ease-out-kael)]",
        "hover:bg-white/[0.07] hover:text-txt-1 active:bg-white/[0.03]",
        active && "bg-phos-500/12 text-phos-300 shadow-[inset_0_0_0_1px_rgb(61_220_100/0.35)]",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

/* =================================================================== chips */
export function Chip({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "phos" | "amber" | "err" | "dusk";
  className?: string;
}) {
  const tones = {
    neutral: "border-white/10 bg-white/[0.04] text-txt-2",
    phos: "border-phos-500/35 bg-phos-900/60 text-phos-300",
    amber: "border-amber-400/35 bg-amber-900/50 text-amber-300",
    err: "border-alert-400/35 bg-alert-900/60 text-alert-400",
    dusk: "border-white/[0.07] bg-black/40 text-txt-3",
  }[tone];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-[3px] font-mono text-[10px] uppercase tracking-[0.16em]",
        tones,
        className,
      )}
    >
      {children}
    </span>
  );
}

/* ================================================================== cards */
export function Card({
  tone = "glass",
  className,
  children,
}: {
  tone?: "glass" | "amber" | "err" | "phos" | "well";
  className?: string;
  children: ReactNode;
}) {
  const tones = {
    glass: "glass-2 inner-top-light",
    well: "rounded-card border border-white/[0.07] bg-black/45",
    amber: "rounded-card border border-amber-400/30 bg-amber-400/[0.06] shadow-glow-amber",
    err: "rounded-card border border-alert-400/30 bg-alert-400/[0.05]",
    phos: "rounded-card border border-phos-500/30 bg-phos-900/40",
  }[tone];
  return <div className={cn(tones, className)}>{children}</div>;
}

/* ================================================================ tooltip */
export function Tooltip({
  text,
  children,
  className,
  side = "top",
}: {
  text: string;
  children: ReactNode;
  className?: string;
  side?: "top" | "bottom";
}) {
  const [copied, setCopied] = useState(false);
  return (
    <span className={cn("group/tt relative inline-flex max-w-full", className)}>
      {children}
      <span
        role="tooltip"
        className={cn(
          "pointer-events-none absolute left-0 z-40 max-w-[340px] translate-y-0 scale-[0.98] rounded-lg border border-white/12 bg-[#0b0f0d]/97 px-2.5 py-1.5",
          "font-mono text-[10.5px] leading-[16px] break-all text-txt-2 shadow-[0_18px_40px_-14px_rgb(0_0_0/0.9)] backdrop-blur",
          "opacity-0 transition duration-150 ease-[var(--ease-out-kael)] group-hover/tt:pointer-events-auto group-hover/tt:scale-100 group-hover/tt:opacity-100",
          "group-focus-within/tt:pointer-events-auto group-focus-within/tt:scale-100 group-focus-within/tt:opacity-100",
          side === "top" ? "bottom-full mb-2" : "top-full mt-2",
        )}
      >
        <span className="flex items-start gap-2">
          <span className="min-w-0">{text}</span>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              navigator.clipboard?.writeText(text);
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1200);
            }}
            className="mt-[1px] shrink-0 text-txt-3 transition hover:text-phos-300"
            aria-label="Copy path"
            title="Copy to clipboard"
          >
            <Copy width={13} height={13} />
          </button>
        </span>
        {copied ? (
          <span className="mt-1 block text-[10px] uppercase tracking-[0.18em] text-phos-400">copied</span>
        ) : null}
      </span>
    </span>
  );
}

/* ================================================================ position */
export function Meter({
  required,
  free,
  available,
  className,
}: {
  required: number;
  free: number;
  available: boolean;
  className?: string;
}) {
  const pctReq = Math.min(100, Math.max(1.5, (required / free) * 100));
  return (
    <div className={cn("space-y-2", className)}>
      <div className="relative h-[10px] overflow-hidden rounded-full border border-white/[0.09] bg-black/60">
        <div className="tex-hatch absolute inset-y-0 right-0" style={{ width: `${100 - pctReq}%` }} />
        <div
          className={cn(
            "absolute inset-y-0 left-0 rounded-full transition-[width] duration-500 ease-[var(--ease-out-kael)]",
            available
              ? "bg-gradient-to-r from-phos-600 to-phos-400 shadow-[0_0_18px_-2px_rgb(61_220_100/0.6)]"
              : "stripes border-r border-amber-300/60",
          )}
          style={{ width: `${pctReq}%` }}
        />
      </div>
      <div className="flex items-center justify-between font-mono text-[10.5px]">
        <span className="flex items-center gap-3 text-txt-3">
          <span className="flex items-center gap-1.5">
            <i
              className={cn(
                "inline-block h-[7px] w-[7px] rounded-full",
                available ? "bg-phos-500" : "bg-amber-400",
              )}
            />
            required {required.toFixed(1)} MB
          </span>
          <span className="flex items-center gap-1.5">
            <i className="inline-block h-[7px] w-[7px] rounded-full border border-white/25" />
            free {free >= 1024 ? `${(free / 1024).toFixed(1)} GB` : `${free.toFixed(0)} MB`}
          </span>
        </span>
        <span className={cn("tnum", available ? "text-phos-400" : "text-amber-400")}>
          {available ? "space ok" : `short by ${(required - free).toFixed(0)} MB`}
        </span>
      </div>
    </div>
  );
}

/* ============================================================ progress bar */
export function PhaseStepper({
  phases,
  activePhase,
  labels,
  done,
}: {
  phases: PhaseId[];
  activePhase: PhaseId;
  labels: Record<PhaseId, string>;
  done: boolean;
}) {
  const activeIdx = phases.indexOf(activePhase);
  return (
    <div className="flex items-center gap-2">
      {phases.map((p, i) => {
        const complete = done || i < activeIdx;
        const active = !done && i === activeIdx;
        return (
          <div key={p} className="flex items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-[4px] font-mono text-[10px] uppercase tracking-[0.18em] transition-all duration-200 ease-[var(--ease-out-kael)]",
                complete && "border-phos-500/40 bg-phos-900/70 text-phos-300",
                active &&
                  "border-phos-400/70 bg-phos-500/[0.14] text-phos-200 shadow-[0_0_20px_-6px_rgb(61_220_100/0.85)]",
                !complete && !active && "border-white/[0.09] bg-white/[0.02] text-txt-3",
              )}
            >
              <i
                className={cn(
                  "h-[6px] w-[6px] rounded-full",
                  complete && "bg-phos-400",
                  active && "light-pulse bg-phos-300",
                  !complete && !active && "bg-white/20",
                )}
              />
              {labels[p]}
              {complete ? <Check width={11} height={11} className="text-phos-400" /> : null}
            </span>
            {i < phases.length - 1 ? (
              <span
                className={cn(
                  "h-px w-6 transition-colors duration-300",
                  i < activeIdx || done ? "bg-phos-500/50" : "bg-white/10",
                )}
              />
            ) : null}
          </div>
        );
      })}
    </div>
  );
}

/* ================================================================ log feed */
const LEVEL_STYLE: Record<string, { c: string; g: string }> = {
  info: { c: "text-txt-2", g: "·" },
  ok: { c: "text-phos-300", g: "✓" },
  warn: { c: "text-amber-400", g: "!" },
  err: { c: "text-alert-400", g: "✗" },
  dim: { c: "text-txt-3", g: " " },
};

export function LogFeed({
  logs,
  running,
  className,
  label = "stdout · kael-setup.log",
}: {
  logs: LogEntry[];
  running: boolean;
  className?: string;
  label?: string;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [pinned, setPinned] = useState(true);
  const [hovering, setHovering] = useState(false);

  useEffect(() => {
    if (!pinned || hovering) return;
    const el = boxRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs, pinned, hovering]);

  const onScroll = () => {
    const el = boxRef.current;
    if (!el) return;
    setPinned(el.scrollHeight - el.scrollTop - el.clientHeight < 24);
  };

  return (
    <div className={cn("relative flex min-h-0 flex-col overflow-hidden rounded-card border border-white/[0.08] bg-black/50", className)}>
      <div className="tex-grid-fine pointer-events-none absolute inset-0 opacity-[0.5]" />
      <div className="relative flex shrink-0 items-center justify-between border-b border-white/[0.07] bg-white/[0.015] px-3 py-2">
        <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-txt-3">
          <Terminal width={13} height={13} className="text-phos-400/80" />
          {label}
        </span>
        <span className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3">
          <span>{logs.length} lines</span>
          <span className="flex items-center gap-1.5">
            <i
              className={cn(
                "h-[6px] w-[6px] rounded-full",
                running ? "light-pulse bg-phos-400" : "bg-white/25",
              )}
            />
            {running ? "streaming" : "idle"}
          </span>
          {!pinned ? <span className="text-amber-400">auto-scroll paused</span> : null}
        </span>
      </div>

      <div
        ref={boxRef}
        onScroll={onScroll}
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
        role="log"
        aria-live="polite"
        aria-atomic="false"
        tabIndex={0}
        className="scroll-thin relative min-h-0 flex-1 overflow-y-auto px-3 py-2.5"
      >
        {logs.map((l, i) => {
          const st = LEVEL_STYLE[l.level] ?? LEVEL_STYLE.info;
          return (
            <div
              key={l.id}
              className={cn(
                "flex gap-2.5 font-mono text-[11.5px] leading-[18px] whitespace-pre-wrap",
                st.c,
                i === logs.length - 1 && running && "anim-step",
              )}
            >
              <span className="w-[42px] shrink-0 text-right text-txt-3/70 tnum">{`${String(Math.floor(l.t / 60000)).padStart(2, "0")}:${String(Math.floor((l.t % 60000) / 1000)).padStart(2, "0")}`}</span>
              <span className="w-[10px] shrink-0 opacity-90">{st.g}</span>
              <span className="min-w-0 flex-1 break-words">{l.text}</span>
            </div>
          );
        })}
        {running ? (
          <div className="flex items-center gap-2 font-mono text-[11.5px] leading-[18px] text-phos-300/80">
            <span className="w-[42px] shrink-0" />
            <span className="w-[10px] shrink-0" />
            <span className="caret h-[13px] w-[7px]" />
          </div>
        ) : null}
      </div>

      {!pinned ? (
        <button
          type="button"
          onClick={() => {
            setPinned(true);
            const el = boxRef.current;
            if (el) el.scrollTop = el.scrollHeight;
          }}
          className="anim-toast absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-phos-500/40 bg-[#0b120e]/95 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-phos-300 shadow-glow"
        >
          <span className="flex items-center gap-1.5">
            <ChevronDown width={12} height={12} /> jump to live
          </span>
        </button>
      ) : null}
    </div>
  );
}

/* ============================================================ option row */
export function OptionRow({
  checked,
  locked,
  disabled,
  onToggle,
  title,
  desc,
  meta,
  icon,
}: {
  checked: boolean;
  locked?: boolean;
  disabled?: boolean;
  onToggle?: () => void;
  title: string;
  desc: string;
  meta: string;
  icon: ReactNode;
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-disabled={disabled || locked}
      disabled={disabled || locked}
      onClick={onToggle}
      className={cn(
        "group flex w-full items-start gap-3 rounded-card border px-3.5 py-3 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
        "hover:border-white/16 hover:bg-white/[0.05] focus-visible:outline-none",
        checked ? "border-phos-500/30 bg-phos-900/35" : "border-white/[0.08] bg-white/[0.02]",
        locked && "cursor-default opacity-80 hover:border-white/[0.08] hover:bg-white/[0.02]",
        disabled && "cursor-not-allowed opacity-40",
      )}
    >
      <span
        className={cn(
          "mt-[1px] grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border transition-all duration-150",
          checked
            ? "border-phos-500 bg-phos-500 text-obsidian shadow-[0_0_14px_-3px_rgb(61_220_100/0.9)]"
            : "border-white/20 bg-black/40 text-transparent",
          locked && "border-white/12 bg-white/[0.05] text-txt-3",
        )}
      >
        {locked ? <Lock width={11} height={11} /> : <Check width={12} height={12} className={checked ? "draw-check" : ""} />}
      </span>

      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-3">
          <span className={cn("font-display text-[13.5px] font-semibold tracking-tight", checked ? "text-txt-1" : "text-txt-2")}>
            {title}
          </span>
          <span className="shrink-0 font-mono text-[10.5px] tracking-tight text-txt-3 tnum">{meta}</span>
        </span>
        <span className="mt-1 block font-mono text-[11px] leading-[17px] text-txt-3">{desc}</span>
      </span>

      <span className={cn("mt-[1px] shrink-0 transition-colors", checked ? "text-phos-400" : "text-txt-3")}>{icon}</span>
    </button>
  );
}

/* ================================================================== notice */
export function Notice({
  tone,
  title,
  children,
  action,
  icon,
}: {
  tone: "amber" | "err" | "phos" | "info";
  title: string;
  children?: ReactNode;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  const map = {
    amber: { c: "border-amber-400/30 bg-amber-400/[0.05]", t: "text-amber-300", card: "amber" },
    err: { c: "border-alert-400/30 bg-alert-400/[0.05]", t: "text-alert-400", card: "err" },
    phos: { c: "border-phos-500/30 bg-phos-900/40", t: "text-phos-300", card: "phos" },
    info: { c: "border-white/[0.09] bg-white/[0.03]", t: "text-txt-2", card: "glass" },
  }[tone];
  return (
    <div className={cn("anim-rise flex items-start gap-3 rounded-card border px-3.5 py-3", map.c)}>
      {icon ? <span className={cn("mt-[1px] shrink-0", map.t)}>{icon}</span> : null}
      <div className="min-w-0 flex-1">
        <p className={cn("font-mono text-[12px] font-medium tracking-tight", map.t)}>{title}</p>
        {children ? <div className="mt-1 font-mono text-[11px] leading-[17px] text-txt-2">{children}</div> : null}
      </div>
      {action ? <div className="shrink-0 self-center">{action}</div> : null}
    </div>
  );
}

/* =================================================================== stats */
export function Stat({ k, v, tone }: { k: string; v: ReactNode; tone?: "phos" | "amber" | "err" }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-white/[0.06] py-1.5 last:border-0">
      <span className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-txt-3">{k}</span>
      <span
        className={cn(
          "font-mono text-[11.5px] tracking-tight tnum",
          tone === "phos" ? "text-phos-300" : tone === "amber" ? "text-amber-300" : tone === "err" ? "text-alert-400" : "text-txt-1",
        )}
      >
        {v}
      </span>
    </div>
  );
}
