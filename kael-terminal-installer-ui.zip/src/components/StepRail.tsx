import { cn } from "../utils/cn";
import { Check, Glyph, Lock, Trash } from "./Icons";

export type RailStep = {
  id: string;
  label: string;
  sub: string;
};

export function StepRail({
  steps,
  current,
  reached,
  onSelect,
  mode,
  onUninstall,
  uninstallEnabled,
}: {
  steps: RailStep[];
  current: number;
  reached: number;
  onSelect: (i: number) => void;
  mode: "install" | "uninstall";
  onUninstall: () => void;
  uninstallEnabled: boolean;
}) {
  return (
    <nav
      aria-label="Setup steps"
      className="hair-r relative z-10 flex w-[196px] shrink-0 flex-col bg-[linear-gradient(180deg,rgb(255,255,255/0.022),transparent)] px-3.5 pt-4 pb-4"
    >
      <div className="mb-4 flex items-center gap-2 pl-1">
        <span className="label-micro">flow</span>
        <span className="h-px flex-1 bg-white/10" />
      </div>

      <ol className="relative flex flex-col gap-0.5">
        {steps.map((s, i) => {
          const done = i < current || (i < reached && i !== current);
          const active = i === current;
          const locked = !done && !active;
          const isUninstallStep = mode === "uninstall" && s.id === "uninstalling";
          return (
            <li key={s.id} className="relative">
              {/* connector */}
              {i < steps.length - 1 ? (
                <span
                  className={cn(
                    "absolute left-[10px] top-[30px] h-[calc(100%-14px)] w-px",
                    i < current ? "bg-phos-500/45" : "bg-white/[0.09]",
                  )}
                />
              ) : null}

              <button
                type="button"
                disabled={locked}
                aria-current={active ? "step" : undefined}
                onClick={() => !locked && onSelect(i)}
                className={cn(
                  "group relative flex w-full items-start gap-3 rounded-[10px] px-1.5 py-1.5 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
                  !locked && "hover:bg-white/[0.05]",
                  locked && "cursor-default",
                )}
              >
                <span className="relative mt-[3px] grid h-[22px] w-[22px] shrink-0 place-items-center">
                  {active ? (
                    <>
                      <span className="absolute h-[22px] w-[22px] rounded-full bg-phos-500/12 shadow-[inset_0_0_0_1px_rgb(61_220_100/0.45)]" />
                      <span className="light-pulse h-[7px] w-[7px] rounded-full bg-phos-400 shadow-[0_0_12px_2px_rgb(61_220_100/0.7)]" />
                    </>
                  ) : done ? (
                    <span className="grid h-[18px] w-[18px] place-items-center rounded-full border border-phos-500/45 bg-phos-900/70 text-phos-300">
                      <Check width={11} height={11} />
                    </span>
                  ) : (
                    <span
                      className={cn(
                        "grid h-[18px] w-[18px] place-items-center rounded-full border",
                        isUninstallStep ? "border-amber-400/40 text-amber-400" : "border-white/12 text-txt-3",
                      )}
                    >
                      <Lock width={10} height={10} />
                    </span>
                  )}
                </span>

                <span className="min-w-0 flex-1 pb-[2px]">
                  <span
                    className={cn(
                      "block font-mono text-[11px] uppercase tracking-[0.14em] transition-colors",
                      active ? "text-phos-200" : done ? "text-txt-2 group-hover:text-txt-1" : "text-txt-3/70",
                    )}
                  >
                    {s.label}
                  </span>
                  <span className={cn("mt-[2px] block truncate font-mono text-[10px] tracking-tight", active ? "text-txt-3" : "text-txt-3/70")}>
                    {s.sub}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ol>

      <div className="mt-auto space-y-3">
        <div className="flex items-center gap-2 pl-1">
          <span className="label-micro">maintenance</span>
          <span className="h-px flex-1 bg-[repeating-linear-gradient(90deg,rgb(255_255_255/0.14)_0_3px,transparent_3px_7px)]" />
        </div>
        <button
          type="button"
          disabled={!uninstallEnabled}
          aria-current={mode === "uninstall" ? "step" : undefined}
          onClick={onUninstall}
          className={cn(
            "flex w-full items-center gap-2.5 rounded-[10px] border px-2.5 py-2 text-left transition-all duration-150 ease-[var(--ease-out-kael)]",
            mode === "uninstall"
              ? "border-amber-400/40 bg-amber-400/[0.07] text-amber-300 shadow-glow-amber"
              : "border-white/[0.08] bg-white/[0.02] text-txt-3 hover:border-amber-400/30 hover:text-amber-300 disabled:hover:border-white/[0.08] disabled:hover:text-txt-3 disabled:opacity-40",
          )}
        >
          <Trash width={14} height={14} />
          <span className="min-w-0 flex-1">
            <span className="block font-mono text-[10.5px] uppercase tracking-[0.16em]">uninstall</span>
            <span className="block truncate font-mono text-[9.5px] tracking-tight text-txt-3">
              {uninstallEnabled ? "remove KAEL 1.0.5" : "installed apps only"}
            </span>
          </span>
        </button>

        <div className="flex items-center gap-2 px-1">
          <Glyph width={13} height={13} className="text-phos-500/70" />
          <span className="font-mono text-[9.5px] tracking-tight text-txt-3">Kael Systems Ltd. · build 26100</span>
        </div>
      </div>
    </nav>
  );
}
