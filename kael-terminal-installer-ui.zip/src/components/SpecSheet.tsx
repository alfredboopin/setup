import { useState } from "react";
import { Copy, WinClose } from "./Icons";
import { Button, MicroLabel } from "./ui";
import {
  a11yNotes,
  colorTokens,
  motionTokens,
  packagingNotes,
  progressPhases,
  radii,
  spacingScale,
  svgAssets,
  typeScale,
} from "../lib/spec";

function Section({ title, kicker, children }: { title: string; kicker?: string; children: React.ReactNode }) {
  return (
    <section className="border-b border-white/[0.07] px-5 py-4">
      <div className="mb-2.5 flex items-baseline gap-2">
        <h3 className="font-display text-[13px] font-semibold tracking-tight text-txt-1">{title}</h3>
        {kicker ? <span className="font-mono text-[10px] tracking-tight text-txt-3">{kicker}</span> : null}
      </div>
      {children}
    </section>
  );
}

function Table({ head, rows }: { head: string[]; rows: React.ReactNode[][] }) {
  return (
    <div className="overflow-hidden rounded-[10px] border border-white/[0.07]">
      <table className="w-full border-collapse text-left">
        <thead>
          <tr className="border-b border-white/[0.07] bg-white/[0.025]">
            {head.map((h) => (
              <th key={h} className="px-2.5 py-1.5 font-mono text-[9.5px] uppercase tracking-[0.16em] text-txt-3">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-white/[0.05] last:border-0 odd:bg-white/[0.012]">
              {r.map((c, j) => (
                <td key={j} className="px-2.5 py-1.5 align-top font-mono text-[10.5px] leading-[16px] text-txt-2">
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SpecSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [copied, setCopied] = useState(false);

  const json = JSON.stringify({ colorTokens, typeScale, spacingScale, radii, motionTokens, progressPhases }, null, 2);

  if (!open) return null;

  return (
    <aside
      role="dialog"
      aria-label="Design spec sheet"
      className="anim-rise absolute right-0 top-[42px] bottom-0 z-40 flex w-[430px] flex-col overflow-hidden rounded-glass rounded-r-none border border-white/[0.1] border-r-0 bg-[#0a0e0c]/98 shadow-[-40px_0_90px_-40px_rgb(0_0_0/1)] backdrop-blur-xl"
    >
      <header className="flex h-[52px] shrink-0 items-center gap-2.5 border-b border-white/[0.08] bg-white/[0.02] px-4">
        <span className="h-2 w-2 rounded-full bg-phos-500 shadow-[0_0_12px_-1px_rgb(61_220_100/0.9)]" />
        <div>
          <div className="font-display text-[13.5px] font-semibold tracking-tight text-txt-1">Terminal Luxe — spec sheet</div>
          <div className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-txt-3">tokens · scale · motion · assets</div>
        </div>
        <span className="flex-1" />
        <Button
          size="sm"
          variant="quiet"
          icon={<Copy width={12} height={12} />}
          onClick={() => {
            navigator.clipboard?.writeText(json);
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1400);
          }}
        >
          {copied ? "copied" : "tokens.json"}
        </Button>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close spec sheet"
          className="grid h-7 w-7 place-items-center rounded-[7px] text-txt-3 transition hover:bg-white/[0.07] hover:text-txt-1"
        >
          <WinClose width={13} height={13} />
        </button>
      </header>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
        <Section title="Window anatomy" kicker="900 × 620 logical px">
          <pre className="overflow-hidden rounded-[10px] border border-white/[0.07] bg-black/50 p-3 font-mono text-[10px] leading-[16px] text-txt-3">{`┌─ title bar ───────────────── 42  frameless, draggable
│ rail 196 │ content            body  flex
│          │                    CTA   56  footer
└─ status strip ─────────────── 26  build + payload
 gap 24 ↔ viewport · scale from host DPI
 radius 16 (Win 11) / square (10 1809+)`}</pre>
        </Section>

        {colorTokens.map((g) => (
          <Section key={g.group} title={`Color — ${g.group}`}>
            <div className="space-y-1.5">
              {g.tokens.map((t) => (
                <div key={t.name} className="flex items-start gap-2.5 rounded-[9px] border border-white/[0.06] bg-white/[0.015] p-2">
                  <span
                    className="mt-[1px] h-6 w-6 shrink-0 rounded-[6px] border border-white/15"
                    style={{
                      background: t.hex.startsWith("rgba")
                        ? "linear-gradient(135deg,rgb(255 255 255/0.05),rgb(255 255 255/0.015))"
                        : t.hex,
                      boxShadow: t.hex.startsWith("rgba") ? "inset 0 0 0 1px rgb(255 255 255/0.06)" : "none",
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="truncate font-mono text-[11px] tracking-tight text-txt-1">{t.name}</span>
                      <span className="font-mono text-[10px] text-txt-3 tnum">{t.hex}</span>
                      {t.contrast ? (
                        <span className="ml-auto shrink-0 rounded-full border border-phos-500/30 bg-phos-900/60 px-1.5 py-[1px] font-mono text-[9px] text-phos-300">
                          {t.contrast}
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-1 font-mono text-[10px] leading-[15px] text-txt-3">{t.usage}</div>
                  </div>
                </div>
              ))}
            </div>
          </Section>
        ))}

        <Section title="Type scale" kicker="JetBrains Mono + Space Grotesk">
          <Table
            head={["role", "face/size", "tracking", "sample"]}
            rows={typeScale.map((t) => [t.role, `${t.font} · ${t.size}`, t.tracking, <span className="text-txt-1">{t.sample}</span>])}
          />
        </Section>

        <Section title="Spacing scale" kicker="4px base">
          <Table head={["token", "px", "use"]} rows={spacingScale.map((s) => [s.token, <span className="text-phos-300 tnum">{s.px}</span>, s.use])} />
        </Section>

        <Section title="Radii">
          <Table head={["token", "px", "use"]} rows={radii.map((r) => [r.token, <span className="tnum">{r.px}</span>, r.use])} />
        </Section>

        <Section title="Motion tokens" kicker="ease-out cubic-bezier(.22,.9,.27,1)">
          <Table head={["token", "value", "use"]} rows={motionTokens.map((m) => [m.token, <span className="text-amber-300">{m.value}</span>, m.use])} />
        </Section>

        <Section title="Progress phase weights" kicker="deterministic, never faked">
          <Table
            head={["phase", "install", "weight", "work"]}
            rows={progressPhases.map((p) => [p.id, `${p.install} / ${p.uninstall}`, <span className="tnum">{p.weight}</span>, p.work])}
          />
        </Section>

        <Section title="SVG asset manifest" kicker={`${svgAssets.length} files · all inlined`}>
          <Table head={["file", "size", "purpose"]} rows={svgAssets.map((a) => [a.name, <span className="text-txt-3 tnum">{a.size}</span>, a.use])} />
        </Section>

        <Section title="Accessibility">
          <ul className="space-y-1.5">
            {a11yNotes.map((n) => (
              <li key={n} className="flex gap-2 font-mono text-[10.5px] leading-[16px] text-txt-2">
                <span className="mt-[6px] h-[5px] w-[5px] shrink-0 rounded-full bg-phos-500/70" />
                <span>{n}</span>
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Packaging & platform constraints">
          <ul className="space-y-1.5">
            {packagingNotes.map((n) => (
              <li key={n} className="flex gap-2 font-mono text-[10.5px] leading-[16px] text-txt-2">
                <span className="mt-[6px] h-[5px] w-[5px] shrink-0 rounded-full bg-amber-400/70" />
                <span>{n}</span>
              </li>
            ))}
          </ul>
        </Section>

        <div className="px-5 py-4">
          <MicroLabel>deliverables</MicroLabel>
          <p className="mt-2 font-mono text-[10.5px] leading-[17px] text-txt-3">
            7 screens · 3 components (rail, glass modal, log feed) · token block in <span className="text-txt-2">src/index.css</span> · asset
            manifest as inline React SVGs in <span className="text-txt-2">src/components/Icons.tsx</span>. Zero runtime fetches.
          </p>
        </div>
      </div>
    </aside>
  );
}
