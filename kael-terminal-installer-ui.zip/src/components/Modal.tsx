import { useEffect, useRef, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { Glyph } from "./Icons";

export function Modal({
  open,
  title,
  eyebrow,
  children,
  actions,
  onClose,
  tone = "default",
}: {
  open: boolean;
  title: string;
  eyebrow?: string;
  children?: ReactNode;
  actions: ReactNode;
  onClose: () => void;
  tone?: "default" | "warn";
}) {
  const panel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const node = panel.current;
    const focusables = node?.querySelectorAll<HTMLElement>(
      'button:not([disabled]),[href],input,[tabindex]:not([tabindex="-1"])',
    );
    (focusables?.length ? (node?.querySelector<HTMLElement>("[data-autofocus]") ?? focusables[0]) : node)?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key !== "Tab" || !node) return;
      const list = Array.from(
        node.querySelectorAll<HTMLElement>('button:not([disabled]),[href],input,[tabindex]:not([tabindex="-1"])'),
      ).filter((el) => el.offsetParent !== null);
      if (!list.length) return;
      const first = list[0];
      const last = list[list.length - 1];
      if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    };
    node?.addEventListener("keydown", onKey);
    return () => node?.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="absolute inset-0 z-40 grid place-items-center rounded-[16px] bg-black/55 backdrop-blur-[3px]"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="vignette pointer-events-none absolute inset-0 rounded-[16px]" />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        className={cn(
          "anim-rise relative w-[400px] rounded-glass border p-5 shadow-[0_40px_90px_-30px_rgb(0_0_0/0.95)] outline-none backdrop-blur-xl",
          tone === "warn" ? "border-amber-400/30 bg-[#0c0f0d]/97" : "border-white/[0.1] bg-[#0b0f0d]/97",
        )}
      >
        <div className="flex items-start gap-3">
          <span
            className={cn(
              "mt-[2px] grid h-8 w-8 shrink-0 place-items-center rounded-[10px] border",
              tone === "warn"
                ? "border-amber-400/35 bg-amber-400/10 text-amber-300"
                : "border-phos-500/30 bg-phos-900/50 text-phos-300",
            )}
          >
            <Glyph width={16} height={16} />
          </span>
          <div className="min-w-0 flex-1">
            {eyebrow ? <div className="label-micro">{eyebrow}</div> : null}
            <h2 className="mt-1 font-display text-[16px] font-semibold tracking-tight text-txt-1">{title}</h2>
          </div>
        </div>

        {children ? <div className="mt-3.5 font-mono text-[11.5px] leading-[18px] text-txt-2">{children}</div> : null}

        <div className="mt-5 flex items-center justify-end gap-2">{actions}</div>
      </div>
    </div>
  );
}
