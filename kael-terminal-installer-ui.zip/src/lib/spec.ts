/**
 * KAEL SETUP — design spec data.
 * Single source of truth for the spec sheet panel & the CSS token block.
 */

export type ColorToken = {
  name: string;
  hex: string;
  usage: string;
  contrast?: string;
};

export const colorTokens: { group: string; tokens: ColorToken[] }[] = [
  {
    group: "surfaces",
    tokens: [
      { name: "--kael-bg / obsidian", hex: "#0A0C0B", usage: "App + window base. Zero white-flash launch." },
      { name: "obsidian-2", hex: "#0D100E", usage: "Recessed wells: log feed, license panel." },
      { name: "obsidian-3", hex: "#121714", usage: "Inputs, chips, inactive rows." },
      { name: "glass fill", hex: "rgba(255,255,255,.02–.04)", usage: "Floating panels, cards, modal." },
      { name: "hairline", hex: "rgba(255,255,255,.08)", usage: "1px panel borders, dividers." },
    ],
  },
  {
    group: "phosphor",
    tokens: [
      { name: "phos-500 / accent", hex: "#3DDC64", usage: "Primary action, active rail dot, progress fill." },
      { name: "phos-400", hex: "#5FE87F", usage: "Hover, focus ring, active text." },
      { name: "phos-300", hex: "#8AF29B", usage: "Log OK level, success headline, glow text." },
      { name: "phos-900", hex: "#0C2814", usage: "Accent wash backgrounds (16% intent)." },
    ],
  },
  {
    group: "signal",
    tokens: [
      { name: "amber-400 / warn", hex: "#FFB454", usage: "Insufficient space, AV/admin note, cancel path." },
      { name: "alert-400 / error", hex: "#FF8172", usage: "Failed install, error log lines, destructive." },
    ],
  },
  {
    group: "type",
    tokens: [
      { name: "txt-1", hex: "#E8F2EC", usage: "Headings, primary values.", contrast: "15.9:1" },
      { name: "txt-2", hex: "#A7B8AE", usage: "Body copy, descriptions.", contrast: "8.9:1" },
      { name: "txt-3", hex: "#7C8D83", usage: "Micro-labels, timestamps.", contrast: "4.8:1 — AA" },
    ],
  },
];

export const typeScale = [
  { role: "Display / splash glyph", font: "Mono 700", size: "34 / 40 px", tracking: "-0.02em", sample: "KAEL" },
  { role: "Step title", font: "Space Grotesk 700", size: "22 / 28 px", tracking: "-0.01em", sample: "Install location" },
  { role: "Panel title", font: "Space Grotesk 600", size: "15 / 22 px", tracking: "0", sample: "End-user license agreement" },
  { role: "Body", font: "Mono 400", size: "12.5 / 19 px", tracking: "0", sample: "Extracting app.asar to disk…" },
  { role: "Micro label", font: "Mono 500", size: "10 / 12 px", tracking: "0.22em ✓ uppercase", sample: "COMPONENTS" },
  { role: "Path / log", font: "Mono 400–500", size: "11.5 / 18 px", tracking: "0", sample: "C:\\Program Files\\KAEL" },
];

export const spacingScale = [
  { token: "space-1", px: 4, use: "icon↔label, chip inner" },
  { token: "space-2", px: 8, use: "tight stacks, inline gaps" },
  { token: "space-3", px: 12, use: "control inner padding" },
  { token: "space-4", px: 16, use: "card padding (compact)" },
  { token: "space-5", px: 20, use: "rail gutter, footer inset" },
  { token: "space-6", px: 24, use: "card padding, step gutter" },
  { token: "space-8", px: 32, use: "section separation" },
  { token: "space-10", px: 40, use: "splash breathing room" },
];

export const radii = [
  { token: "radius-window", px: 16, use: "window chrome (Win 11 rounding)" },
  { token: "radius-glass", px: 16, use: "floating panels, modal" },
  { token: "radius-card", px: 12, use: "cards, log well, list rows" },
  { token: "radius-pill", px: 999, use: "chips, meters, primary CTA" },
];

export const motionTokens = [
  { token: "dur-instant", value: "90 ms", use: "hover tint, pressed glow drop" },
  { token: "dur-micro", value: "150 ms", use: "checkbox, tooltip, chip state" },
  { token: "dur-step", value: "200–250 ms", use: "step transition (fade + 8px slide)" },
  { token: "dur-panel", value: "320 ms", use: "spec drawer, modal scale-in" },
  { token: "ease-out", value: "cubic-bezier(.22,.9,.27,1)", use: "all entrances, exits, glow" },
  { token: "ease-in", value: "cubic-bezier(.5,0,.75,0)", use: "dismissals only" },
  { token: "shimmer", value: "1600 ms linear ∞", use: "progress bar light sweep" },
  { token: "light-pulse", value: "1400 ms ease-in-out ∞", use: "status LED, active rail dot" },
  { token: "caret-blink", value: "1050 ms steps(1)", use: "heading caret, typing cursor" },
  { token: "check-draw", value: "520 ms + 120 ms delay", use: "success check stroke reveal" },
  { token: "glow-pulse", value: "1500 ms ×1", use: "single success ring expansion" },
];

export const progressPhases = [
  { id: "verify", install: "VERIFY", uninstall: "PRE-FLIGHT", weight: "12%", work: "checksum, signature, VC++ probe" },
  { id: "extract", install: "EXTRACT", uninstall: "REMOVE", weight: "68%", work: "app.asar, runtime, payload stream" },
  { id: "finalize", install: "FINALIZE", uninstall: "CLEANUP", weight: "20%", work: "registry, protocol, shortcuts, prefs" },
];

export const svgAssets = [
  { name: "kael-glyph.svg", size: "1.1 KB", use: "Window + taskbar + rail mark (stroke-only, currentColor)" },
  { name: "kael-wordmark.svg", size: "1.6 KB", use: "Splash typing target (phase-typed, not masked)" },
  { name: "ico-check-draw.svg", size: "0.6 KB", use: "Success check, stroke-dash 100 draw-on" },
  { name: "ico-lock.svg", size: "0.5 KB", use: "Required component, locked step" },
  { name: "ico-folder.svg / ico-path.svg", size: "0.7 KB", use: "Browse picker, path validation" },
  { name: "ico-disk.svg", size: "0.7 KB", use: "Space meter, free vs required" },
  { name: "ico-shield.svg", size: "0.6 KB", use: "Signature/UAC note, verified badge" },
  { name: "ico-terminal.svg", size: "0.7 KB", use: "Log feed header, console affordance" },
  { name: "ico-warn.svg / ico-error.svg", size: "0.6 KB", use: "Amber edge cards, error log" },
  { name: "ico-copy.svg / ico-retry.svg", size: "0.6 KB", use: "Copy log, Retry action" },
  { name: "ico-link.svg", size: "0.5 KB", use: "Explorer context-menu integration" },
  { name: "tx-grid.svg (32px)", size: "0.4 KB", use: "Background grid tile (data-URI inlined)" },
  { name: "tx-scanlines.svg (1×3px)", size: "0.3 KB", use: "CRT scanline tile (repeating-linear-gradient)" },
  { name: "tx-noise.svg (feTurbulence)", size: "0.9 KB", use: "Film grain @ 3% opacity, non-animated" },
  { name: "noise-ring.svg", size: "0.4 KB", use: "One-shot success glow pulse" },
  { name: "win-min.svg / win-close.svg", size: "0.4 KB", use: "Frameless caption controls (1.5px stroke)" },
];

export const a11yNotes = [
  "Tab order: caption controls → step rail → step body → footer CTA. Enter = Next; Esc dismisses the top-most glass modal.",
  "Focus ring: 1px #5FE87F outline, 2px offset, plus 4px 14%-alpha halo — never removed, never custom on inputs.",
  "Contrast: body #A7B8AE 8.9:1, micro-labels #7C8D83 4.8:1, accent-on-dark 9.1:1. Amber/alert used with icon + text, never color alone.",
  "Live regions: install log is aria-live=\"polite\", progress uses role=\"progressbar\" with aria-valuenow; failure card takes focus.",
  "Truncated paths expose full value via title + focusable tooltip, and are copyable from the tooltip.",
];

export const packagingNotes = [
  "Host: NSIS custom-drawn UI + WebView2 bootstrapper (or Win32 host w/ WebView2 fixed-version). Zero outbound requests once setup.exe runs.",
  "Build: Vite → single inlined HTML (JS+CSS+woff2 base64). Measured payload budget 1.4 MB, target < 2 MB.",
  "DPI: per-monitor v2. Layout authored at 900×620 logical px; host sets --kael-scale from monitor DPI, hairline borders stay 1px (not scaled) to avoid blur.",
  "Theme: dark-only. color-scheme: dark only; html background painted #0A0C0B before first paint → no white flash on launch.",
  "Windows 10 1809+ / Windows 11: 1809-21H1 fall back to native rounding-free chrome, Win 11 gets 16px rounded corners + squircle backdrop.",
  "Motion respects prefers-reduced-motion; telemetry-free; log written to %TEMP%\\kael-setup-<ts>.log.",
];

export const shortcuts = [
  { label: "Desktop shortcut", path: "C:\\Users\\Public\\Desktop\\KAEL.lnk" },
  { label: "Start menu entry", path: "%ProgramData%\\Microsoft\\Windows\\Start Menu\\Programs\\KAEL.lnk" },
  { label: "Protocol handler", path: "HKCU\\Software\\Classes\\kael → \"C:\\Program Files\\KAEL\\kael.exe\" \"%1\"" },
  { label: "PATH entry", path: "C:\\Program Files\\KAEL\\bin" },
  { label: "Context menu verb", path: "HKCR\\*\\shell\\Open in KAEL" },
];
