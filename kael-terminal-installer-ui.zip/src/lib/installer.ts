import { useCallback, useEffect, useRef, useState } from "react";

/* ============================================================================
   TYPES
   ========================================================================== */
export type PhaseId = "verify" | "extract" | "finalize";
export type LogLevel = "info" | "ok" | "warn" | "err" | "dim";
export type EngineStatus =
  | "idle"
  | "running"
  | "failed"
  | "rolling-back"
  | "cancelled"
  | "done";

export type LogEntry = {
  id: number;
  t: number;
  level: LogLevel;
  phase: PhaseId;
  text: string;
};

type ScriptTask = {
  phase: PhaseId;
  level: LogLevel;
  text: string;
  ms: number;
  requires?: ("shortcut" | "pathEntry" | "contextMenu")[];
  upgradeOnly?: boolean;
  preservedOnly?: boolean;
};

export type ComponentFlags = {
  shortcut: boolean;
  pathEntry: boolean;
  contextMenu: boolean;
};

export type RunOptions = {
  variant: "install" | "uninstall";
  components: ComponentFlags;
  upgrade: boolean;
  keepSettings: boolean;
  failAtId?: string | null;
  speed?: number;
};

/* ============================================================================
   SCRIPTS — real install/uninstall steps, verbatim style
   ========================================================================== */
const INSTALL_SCRIPT: ScriptTask[] = [
  { phase: "verify", level: "dim", text: "kael-setup.exe v1.0.5 (build 26100.1043) — offline installer, 1.4 MB embedded payload", ms: 220 },
  { phase: "verify", level: "info", text: "acquiring write lock → C:\\Program Files\\KAEL", ms: 340 },
  { phase: "verify", level: "ok", text: "system check: Windows 11 24H2 · x64 · 32 GB RAM · 2.1 TB free", ms: 300 },
  { phase: "verify", level: "info", text: "probing WebView2 runtime 1.0.2903.40", ms: 460 },
  { phase: "verify", level: "ok", text: "runtime present — fixed-version 120.0.2210 bundled as fallback", ms: 280 },
  { phase: "verify", level: "info", text: "verifying checksum sha256: 9f2c4b71…a71e0d", ms: 980 },
  { phase: "verify", level: "ok", text: "signature valid — Authenticode: Kael Systems Ltd. (EV, countersigned)", ms: 320 },
  { phase: "verify", level: "warn", text: "defender surfaced 1 signed binary (kael-hook.dll) for review — expected, allow-listed by publisher", ms: 620 },

  { phase: "extract", level: "info", text: "extracting app.asar → resources\\ (268.4 MB)", ms: 1200 },
  { phase: "extract", level: "dim", text: "  ├─ stream 1/5 …… 54.1 MB  [▓▓▒░░░░░░░] 20%", ms: 720 },
  { phase: "extract", level: "dim", text: "  ├─ stream 2/5 …… 107.6 MB [▓▓▓▓▒░░░░░] 40%", ms: 700 },
  { phase: "extract", level: "dim", text: "  ├─ stream 3/5 …… 161.2 MB [▓▓▓▓▓▓▒░░░] 60%", ms: 690 },
  { phase: "extract", level: "dim", text: "  ├─ stream 4/5 …… 214.9 MB [▓▓▓▓▓▓▓▓▒░] 80%", ms: 680 },
  { phase: "extract", level: "dim", text: "  └─ stream 5/5 …… 268.4 MB [▓▓▓▓▓▓▓▓▓▓] 100%", ms: 760 },
  { phase: "extract", level: "ok", text: "app.asar written + re-hashed post-write (match)", ms: 340 },
  { phase: "extract", level: "info", text: "extracting kael.exe + native runtime (118.2 MB)", ms: 1600 },
  { phase: "extract", level: "ok", text: "native runtime linked — D3D11 hardware accel available", ms: 300 },
  { phase: "extract", level: "info", text: "unpacking glyphs\\, themes\\, keybindings\\ (26.1 MB)", ms: 900 },
  { phase: "extract", level: "info", text: "provisioning local SQLite session store (2.0 MB)", ms: 380 },
  { phase: "extract", level: "ok", text: "payload complete — 412.7 MB committed to disk", ms: 320 },

  { phase: "finalize", level: "info", text: "registering protocol kael://", ms: 420 },
  { phase: "finalize", level: "ok", text: "HKCU\\Software\\Classes\\kael → kael.exe \"%1\"", ms: 240 },
  { phase: "finalize", level: "info", text: "writing uninstall entry → Apps & Features", ms: 360 },
  { phase: "finalize", level: "info", text: "creating desktop shortcut", ms: 300, requires: ["shortcut"] },
  { phase: "finalize", level: "info", text: "creating Start menu entry", ms: 280, requires: ["shortcut"] },
  { phase: "finalize", level: "ok", text: "shell links created (2)", ms: 220, requires: ["shortcut"] },
  { phase: "finalize", level: "info", text: "appending to PATH → C:\\Program Files\\KAEL\\bin", ms: 380, requires: ["pathEntry"] },
  { phase: "finalize", level: "ok", text: "PATH updated — visible to new terminal sessions", ms: 240, requires: ["pathEntry"] },
  { phase: "finalize", level: "info", text: "registering Explorer verb: Open in KAEL", ms: 420, requires: ["contextMenu"] },
  { phase: "finalize", level: "ok", text: "HKCR\\*\\shell\\Open in KAEL created", ms: 240, requires: ["contextMenu"] },
  { phase: "finalize", level: "warn", text: "settings from v1.0.5 detected at %APPDATA%\\KAEL — they will be preserved", ms: 560, upgradeOnly: true },
  { phase: "finalize", level: "info", text: "writing first-run state + license acceptance record", ms: 300 },
  { phase: "finalize", level: "ok", text: "install manifest sealed — 3,412 objects, 0 errors", ms: 300 },
];

const UNINSTALL_SCRIPT: ScriptTask[] = [
  { phase: "verify", level: "dim", text: "kael-uninstall.exe v1.0.5 — removing C:\\Program Files\\KAEL", ms: 240 },
  { phase: "verify", level: "info", text: "pre-flight: querying for running kael.exe processes", ms: 420 },
  { phase: "verify", level: "ok", text: "0 processes holding file handles", ms: 260 },
  { phase: "verify", level: "info", text: "flushing session store + stopping kael-agent service", ms: 640 },
  { phase: "verify", level: "ok", text: "service stopped · autostart entry removed", ms: 300 },
  { phase: "verify", level: "info", text: "verifying removal manifest signature", ms: 520 },
  { phase: "verify", level: "ok", text: "manifest valid — 3,412 objects / 412.7 MB staged", ms: 300 },

  { phase: "extract", level: "info", text: "releasing file locks + clearing VFS cache", ms: 560 },
  { phase: "extract", level: "dim", text: "  ├─ removing glyphs\\, themes\\ …… 26.1 MB", ms: 640 },
  { phase: "extract", level: "dim", text: "  ├─ removing runtime\\ ········· 118.2 MB", ms: 760 },
  { phase: "extract", level: "dim", text: "  ├─ removing app.asar ········· 268.4 MB", ms: 900 },
  { phase: "extract", level: "ok", text: "directory tree removed — 412.7 MB freed", ms: 340 },
  { phase: "extract", level: "ok", text: "0 orphaned staging folders in %TEMP%", ms: 260 },

  { phase: "finalize", level: "info", text: "deleting registry keys (protocol, uninstall entry, file assoc)", ms: 520 },
  { phase: "finalize", level: "ok", text: "kael:// handler released", ms: 240 },
  { phase: "finalize", level: "info", text: "removing shell links (desktop, start menu)", ms: 340 },
  { phase: "finalize", level: "info", text: "removing Explorer verb: Open in KAEL", ms: 320 },
  { phase: "finalize", level: "warn", text: "PATH entry removed — restart open terminals to apply", ms: 400 },
  { phase: "finalize", level: "warn", text: "preserving %APPDATA%\\KAEL — config.json, sessions\\ (1.2 MB retained)", ms: 480, preservedOnly: true },
  { phase: "finalize", level: "ok", text: "cleanup complete — 0 orphan keys, 0 orphan files", ms: 320 },
];

const ROLLBACK_SCRIPT: ScriptTask[] = [
  { phase: "finalize", level: "warn", text: "rollback requested — reverting partial changes", ms: 340 },
  { phase: "finalize", level: "info", text: "releasing write lock on install location", ms: 320 },
  { phase: "finalize", level: "info", text: "deleting partial extract artifacts", ms: 700 },
  { phase: "finalize", level: "ok", text: "partial files removed — disk reclaimed", ms: 260 },
  { phase: "finalize", level: "info", text: "restoring registry snapshot", ms: 480 },
  { phase: "finalize", level: "ok", text: "7 staged keys reverted, protocol handler unchanged", ms: 260 },
  { phase: "finalize", level: "ok", text: "rollback complete — no residue, system unchanged", ms: 300 },
];

export const FAILURE_LOG: LogEntry[] = [];

export const FAIL_MESSAGE =
  "ERROR 0x80070005 — access denied while writing C:\\Program Files\\KAEL\\bin\\kael.exe";

export const FAIL_HINT =
  "hint: antivirus real-time protection or a Group Policy write restriction blocked the final binary.";

export function buildScript(opts: RunOptions): ScriptTask[] {
  const base = opts.variant === "install" ? INSTALL_SCRIPT : UNINSTALL_SCRIPT;
  return base.filter((t) => {
    if (t.requires && !t.requires.some((k) => opts.components[k])) return false;
    if (t.upgradeOnly && !opts.upgrade) return false;
    if (t.preservedOnly && !opts.keepSettings) return false;
    return true;
  });
}

/* Weight of each task in the "deterministic" progress model. */
function weightsOf(tasks: ScriptTask[]) {
  const total = tasks.reduce((s, t) => s + t.ms, 0) || 1;
  return { total, cum: tasks.map((t) => t.ms / total) };
}

/* ============================================================================
   HELPERS
   ========================================================================== */
export function fmtBytes(mb: number) {
  if (mb >= 1024) return `${(mb / 1024).toFixed(2)} GB`;
  return `${mb.toFixed(1)} MB`;
}

export function fmtClock(ms: number) {
  const total = Math.floor(ms / 1000);
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  const cs = String(Math.floor((ms % 1000) / 10)).padStart(2, "0");
  return `${m}:${s}.${cs}`;
}

export function fmtLogTime(ms: number) {
  const total = Math.floor(ms / 1000);
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}

export function logToText(logs: LogEntry[], header: string[]) {
  const lines = [
    ...header,
    ...logs.map(
      (l) => `[${fmtLogTime(l.t)}] ${l.level.toUpperCase().padEnd(4)} ${l.text}`,
    ),
  ];
  return lines.join("\r\n");
}

/* ============================================================================
   ENGINE
   ========================================================================== */
type Internal = {
  tasks: ScriptTask[];
  cum: number[];
  index: number;
  taskElapsed: number;
  doneMs: number;
  total: number;
  elapsed: number;
  logId: number;
  opts: RunOptions;
  mode: "install" | "rollback";
  basePct: number;
  failIndex: number;
  failArmed: boolean;
  emittedFail: boolean;
  lastTick: number;
};

const TICK = 50;

export function useInstallEngine() {
  const [status, setStatus] = useState<EngineStatus>("idle");
  const [pct, setPct] = useState(0);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [elapsedMs, setElapsed] = useState(0);
  const [phase, setPhase] = useState<PhaseId>("verify");
  const [taskCounter, setTaskCounter] = useState({ i: 0, n: 0 });

  const r = useRef<Internal>({
    tasks: [],
    cum: [],
    index: 0,
    taskElapsed: 0,
    doneMs: 0,
    total: 1,
    elapsed: 0,
    logId: 0,
    opts: {
      variant: "install",
      components: { shortcut: true, pathEntry: false, contextMenu: false },
      upgrade: false,
      keepSettings: true,
      speed: 1,
    },
    mode: "install",
    basePct: 0,
    failIndex: -1,
    failArmed: false,
    emittedFail: false,
    lastTick: 0,
  });
  const timer = useRef<number | null>(null);

  const stopTimer = useCallback(() => {
    if (timer.current !== null) {
      window.clearInterval(timer.current);
      timer.current = null;
    }
  }, []);

  const pushLog = useCallback((level: LogLevel, phaseId: PhaseId, text: string) => {
    const s = r.current;
    s.logId += 1;
    const entry: LogEntry = { id: s.logId, t: s.elapsed, level, phase: phaseId, text };
    setLogs((prev) => (prev.length > 900 ? [...prev.slice(-800), entry] : [...prev, entry]));
  }, []);

  const tick = useCallback(() => {
    const s = r.current;
    const now = performance.now();
    const dt = s.lastTick ? Math.min(now - s.lastTick, 400) : TICK;
    s.lastTick = now;
    const speed = s.opts.speed ?? 1;
    s.elapsed += dt;

    const tasks = s.tasks;
    const task = tasks[s.index];

    if (!task) {
      setElapsed(s.elapsed);
      stopTimer();
      setStatus("done");
      setPct(100);
      return;
    }

    if (s.mode === "rollback") {
      s.taskElapsed += dt * speed;
      const frac = Math.min(s.taskElapsed / task.ms, 1);
      setElapsed(s.elapsed);
      setPct(Math.max(0, s.basePct * (1 - frac)));
      if (frac >= 1) {
        pushLog(task.level, task.phase, task.text);
        s.index += 1;
        s.taskElapsed = 0;
        if (s.index >= tasks.length) {
          stopTimer();
          setStatus("cancelled");
          setPct(0);
        }
      }
      return;
    }

    /* failure injection: fail right before the target task commits */
    if (s.failArmed && !s.emittedFail && s.index === s.failIndex) {
      s.failArmed = false;
      s.emittedFail = true;
      pushLog(
        "dim",
        task.phase,
        `  ⟳ retrying write (attempt 2 of 2): ${task.text.slice(0, 62)}`,
      );
      pushLog("err", task.phase, FAIL_MESSAGE);
      pushLog("err", task.phase, FAIL_HINT);
      stopTimer();
      setStatus("failed");
      setElapsed(s.elapsed);
      return;
    }

    s.taskElapsed += dt * speed;
    const frac = Math.min(s.taskElapsed / task.ms, 1);
    setPct((s.doneMs + s.cum[s.index] * frac) * 100);
    setElapsed(s.elapsed);
    setPhase(task.phase);

    if (frac >= 1) {
      pushLog(task.level, task.phase, task.text);
      s.doneMs += s.cum[s.index];
      s.index += 1;
      s.taskElapsed = 0;
      setTaskCounter({ i: s.index, n: tasks.length });
      if (s.index >= tasks.length) {
        stopTimer();
        setStatus("done");
        setPct(100);
        return;
      }
      setPhase(s.tasks[s.index].phase);
    }
  }, [pushLog, stopTimer]);

  const startTimer = useCallback(() => {
    stopTimer();
    r.current.lastTick = 0;
    timer.current = window.setInterval(tick, TICK);
  }, [stopTimer, tick]);

  const start = useCallback(
    (opts: RunOptions) => {
      const s = r.current;
      const tasks = buildScript(opts);
      const { total, cum } = weightsOf(tasks);
      s.opts = opts;
      s.tasks = tasks;
      s.cum = cum;
      s.total = total;
      s.index = 0;
      s.taskElapsed = 0;
      s.doneMs = 0;
      s.elapsed = 0;
      s.mode = "install";
      s.basePct = 0;
      s.emittedFail = false;
      s.failIndex = opts.failAtId ? tasks.findIndex((t) => t.text.includes(opts.failAtId!)) : -1;
      s.failArmed = s.failIndex >= 0;
      setLogs([]);
      setPct(0);
      setPhase("verify");
      setElapsed(0);
      setTaskCounter({ i: 0, n: tasks.length });
      pushLog(
        "dim",
        tasks[0]?.phase ?? "verify",
        opts.variant === "install"
          ? "=== KAEL SETUP · interactive log · nothing leaves this machine ==="
          : "=== KAEL UNINSTALL · interactive log ===",
      );
      setStatus("running");
      startTimer();
    },
    [pushLog, startTimer],
  );

  const retry = useCallback(
    (overrideFailId: string | null = null) => {
      const s = r.current;
      const opts = { ...s.opts, failAtId: overrideFailId };
      start(opts);
    },
    [start],
  );

  const abort = useCallback(() => {
    const s = r.current;
    if (s.mode !== "install") return;
    s.mode = "rollback";
    s.basePct = Math.min(pct, 100);
    s.tasks = ROLLBACK_SCRIPT;
    s.cum = weightsOf(ROLLBACK_SCRIPT).cum;
    s.index = 0;
    s.taskElapsed = 0;
    pushLog("warn", "finalize", "user cancelled — starting safe rollback");
    setStatus("rolling-back");
    startTimer();
  }, [pct, pushLog, startTimer]);

  const reset = useCallback(() => {
    stopTimer();
    const s = r.current;
    s.index = 0;
    s.doneMs = 0;
    s.elapsed = 0;
    s.taskElapsed = 0;
    setLogs([]);
    setPct(0);
    setElapsed(0);
    setStatus("idle");
  }, [stopTimer]);

  useEffect(() => stopTimer, [stopTimer]);

  return {
    status,
    pct,
    logs,
    elapsedMs,
    phase,
    taskCounter,
    start,
    retry,
    abort,
    reset,
  };
}
