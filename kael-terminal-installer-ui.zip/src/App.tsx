import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { cn } from "./utils/cn";
import { Backdrop, StatusStrip, TitleBar } from "./components/Chrome";
import { StepRail, type RailStep } from "./components/StepRail";
import { Modal } from "./components/Modal";
import { SpecSheet } from "./components/SpecSheet";
import { ScenarioPanel, type ScenarioId } from "./components/ScenarioPanel";
import { Button, Chip, IconButton, MicroLabel, Notice } from "./components/ui";
import { Book, Check, Copy, Key, Rocket, Sliders, Spark, Terminal, Warn, ChevronLeft, ChevronRight } from "./components/Icons";
import { Welcome } from "./screens/Welcome";
import { License } from "./screens/License";
import { Components } from "./screens/Components";
import { Location, validatePath, type PathStatus } from "./screens/Location";
import { Installing, copyLogToClipboard } from "./screens/Installing";
import { Finish } from "./screens/Finish";
import { Uninstall } from "./screens/Uninstall";
import { fmtClock, logToText, useInstallEngine, type ComponentFlags } from "./lib/installer";

const W = 900;
const H = 620;

const STEPS: RailStep[] = [
  { id: "welcome", label: "welcome", sub: "kael-setup.exe" },
  { id: "license", label: "licence", sub: "terms · 8 clauses" },
  { id: "location", label: "location", sub: "path · disk space" },
  { id: "components", label: "components", sub: "integration set" },
  { id: "installing", label: "installing", sub: "streaming payload" },
  { id: "finish", label: "finish", sub: "report & launch" },
];

const STEP_META = [
  { title: "Welcome to KAEL Setup", sub: "offline installer · 412.7 MB · windows 10 1809+ / 11" },
  { title: "Licence agreement", sub: "read to the end — acceptance stays locked until you do" },
  { title: "Install location", sub: "choose where the console, runtime and glyph packs live" },
  { title: "Components", sub: "tick the integrations KAEL may register on this machine" },
  { title: "Installing", sub: "live audit log · cancellable at any point, nothing is left behind" },
  { title: "Finish", sub: "verify the report and hand off to the console" },
];

type NoticeState = { tone: "amber" | "err" | "phos" | "info"; title: string; body?: string; action?: { label: string; fn: () => void } } | null;

export default function App() {
  /* ------------------------------------------------------------- view state */
  const [step, setStep] = useState(0);
  const [mode, setMode] = useState<"install" | "uninstall">("install");
  const [uninstallStage, setUninstallStage] = useState<"confirm" | "running" | "done">("confirm");
  const [windowState, setWindowState] = useState<"normal" | "minimized" | "closed">("normal");
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [scale, setScale] = useState(1);

  /* ------------------------------------------------------------- wizard data */
  const [installPath, setInstallPath] = useState("C:\\Program Files\\KAEL");
  const [pathStatus, setPathStatus] = useState<PathStatus>(() => validatePath("C:\\Program Files\\KAEL", false));
  const [accepted, setAccepted] = useState(false);
  const [, setLicensePct] = useState(0);
  const [components, setComponents] = useState<ComponentFlags>({ shortcut: true, pathEntry: false, contextMenu: true });
  const [preserveSettings, setPreserveSettings] = useState(true);
  const [keepSettings, setKeepSettings] = useState(true);
  const [purge, setPurge] = useState(false);
  const [launch, setLaunch] = useState(true);

  /* ------------------------------------------------------------- simulation */
  const [scenario, setScenario] = useState<ScenarioId>("clean");
  const [speed, setSpeed] = useState(1);
  const [showFailureLog, setShowFailureLog] = useState(false);
  const [notice, setNotice] = useState<NoticeState>(null);
  const [toasts, setToasts] = useState<{ id: number; text: string }[]>([]);

  /* ------------------------------------------------------------------ panes */
  const [specOpen, setSpecOpen] = useState(false);
  const [scenOpen, setScenOpen] = useState(false);
  const [cancelModal, setCancelModal] = useState(false);
  const [closeModal, setCloseModal] = useState(false);
  const [logModal, setLogModal] = useState(false);

  const engine = useInstallEngine();
  const startedRef = useRef(false);
  const handledRef = useRef<string | null>(null);
  const bodyRef = useRef<HTMLDivElement>(null);

  const lowDisk = scenario === "lowDisk";
  const avBlock = scenario === "avBlock";
  const upgrade = scenario === "upgrade";
  const failId = scenario === "failure" ? "extracting kael.exe" : null;

  const toast = useCallback((text: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, text }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2200);
  }, []);

  /* ------------------------------------------------------------------ scale */
  useEffect(() => {
    const fit = () => {
      const s = Math.min(1, (window.innerWidth - 40) / W, (window.innerHeight - 40) / H);
      setScale(Math.max(0.42, s));
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  /* -------------------------------------------------------------- drag title */
  const dragRef = useRef({ sx: 0, sy: 0, ox: 0, oy: 0, active: false });
  const onDragStart = (e: React.PointerEvent) => {
    dragRef.current = { sx: e.clientX, sy: e.clientY, ox: offset.x, oy: offset.y, active: true };
    setDragging(true);
    const move = (ev: PointerEvent) => {
      if (!dragRef.current.active) return;
      setOffset({
        x: Math.max(-180, Math.min(180, dragRef.current.ox + (ev.clientX - dragRef.current.sx))),
        y: Math.max(-120, Math.min(120, dragRef.current.oy + (ev.clientY - dragRef.current.sy))),
      });
    };
    const up = () => {
      dragRef.current.active = false;
      setDragging(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  /* ------------------------------------------------------- install lifecycle */
  useEffect(() => {
    if (step !== 4 || mode !== "install" || startedRef.current) return;
    startedRef.current = true;
    engine.start({
      variant: "install",
      components,
      upgrade,
      keepSettings: preserveSettings,
      failAtId: failId,
      speed,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, mode]);

  useEffect(() => {
    const key = `${mode}-${engine.status}`;
    if (handledRef.current === key) return;

    if (mode === "install" && engine.status === "done" && step === 4) {
      handledRef.current = key;
      const t = window.setTimeout(() => setStep(5), 700);
      return () => window.clearTimeout(t);
    }
    if (engine.status === "failed") {
      handledRef.current = key;
      setShowFailureLog(false);
    }
    if (engine.status === "cancelled") {
      handledRef.current = key;
      if (mode === "install") {
        setStep(3);
        setNotice({
          tone: "amber",
          title: "Setup cancelled — rollback complete, system unchanged",
          body: "All staged files and registry writes were reverted. You can adjust components and start again.",
          action: { label: "start over", fn: () => goStep(4) },
        });
      } else {
        setUninstallStage("confirm");
        setNotice({ tone: "info", title: "Uninstall cancelled — KAEL is still installed" });
      }
    }
    if (mode === "uninstall" && engine.status === "done" && uninstallStage === "running") {
      handledRef.current = key;
      setUninstallStage("done");
    }
    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine.status, mode, step, uninstallStage]);

  useEffect(() => {
    bodyRef.current?.focus();
  }, [step, mode, uninstallStage]);

  /* --------------------------------------------------------------- navigation */
  const running = engine.status === "running" || engine.status === "rolling-back";
  const canLeaveInstall = !running;

  const goStep = useCallback(
    (i: number) => {
      if (i === 4) {
        startedRef.current = false;
        handledRef.current = null;
      }
      setNotice(null);
      setStep(i);
    },
    [],
  );

  const handedRefReset = useCallback(() => {
    handledRef.current = null;
  }, []);

  const startInstall = useCallback(() => {
    if (!pathStatus.ok) return;
    goStep(4);
  }, [goStep, pathStatus.ok]);

  const retryInstall = useCallback(
    (variant: "install" | "uninstall") => {
      handedRefReset();
      if (variant === "install" && scenario === "failure") setScenario("clean");
      toast(variant === "install" ? "retrying — exclusion list applied, handles released" : "retrying removal");
      engine.retry(null);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [engine.retry, scenario, toast],
  );

  const startUninstall = useCallback(() => {
    setNotice(null);
    setUninstallStage("running");
    handedRefReset();
    engine.start({ variant: "uninstall", components, upgrade: false, keepSettings, speed });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [components, keepSettings, speed, engine.start]);

  const footerPrimary = useMemo(() => {
    if (mode === "uninstall") {
      if (uninstallStage === "confirm") return { label: "Uninstall KAEL", variant: "warn" as const, fn: startUninstall, disabled: false };
      if (uninstallStage === "done") return { label: "Close setup", variant: "primary" as const, fn: () => setWindowState("closed"), disabled: false };
      return null;
    }
    if (step === 1) return { label: "I accept & continue", variant: "primary" as const, fn: () => goStep(2), disabled: !accepted };
    if (step === 2)
      return {
        label: "Next: components",
        variant: "primary" as const,
        fn: () => goStep(3),
        disabled: !pathStatus.ok,
      };
    if (step === 3) return { label: "Install", variant: "primary" as const, fn: startInstall, disabled: false };
    if (step === 5)
      return {
        label: launch ? "Finish & launch KAEL" : "Finish",
        variant: "primary" as const,
        fn: () => {
          if (launch) {
            toast("launching kael.exe … warm session provisioning");
            window.setTimeout(() => setWindowState("closed"), 1400);
          } else setWindowState("closed");
        },
        disabled: false,
      };
    return null;
  }, [mode, uninstallStage, step, accepted, pathStatus.ok, launch, startInstall, startUninstall, goStep, toast]);

  /* -------------------------------------------------------------- keyboard nav */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (e.key === "Escape") {
        if (cancelModal) return setCancelModal(false);
        if (closeModal) return setCloseModal(false);
        if (logModal) return setLogModal(false);
        if (specOpen) return setSpecOpen(false);
        if (scenOpen) return setScenOpen(false);
        if (running) return setCancelModal(true);
        if (!engine.pct) setCloseModal(true);
        return;
      }
      if (e.key !== "Enter" || e.shiftKey) return;
      const tag = target?.tagName.toLowerCase();
      const inField = tag === "input" || tag === "textarea" || target?.dataset.noEnter === "true";
      const isButton = tag === "button" || target?.getAttribute("role") === "checkbox";
      if (inField || isButton || specOpen || logModal) return;
      if (cancelModal || closeModal || scenOpen) return;
      e.preventDefault();
      if (footerPrimary) {
        if (!footerPrimary.disabled) footerPrimary.fn();
        return;
      }
      if (mode === "install" && step < 3) goStep(step + 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cancelModal, closeModal, logModal, specOpen, scenOpen, running, engine.pct, footerPrimary, mode, step, goStep]);

  /* ------------------------------------------------------------ failure copy */
  const headerFor = (variant: "install" | "uninstall") => [
    `=== KAEL ${variant === "install" ? "SETUP" : "UNINSTALL"} · audit log · ${new Date().toISOString()} ===`,
    `target: ${installPath}`,
    `elevation: administrator (finalize phase only) · network: disabled`,
  ];

  const copyLog = () => {
    copyLogToClipboard(engine.logs, headerFor(mode));
    toast("audit log copied to clipboard");
  };

  const logPath = installPath.startsWith("C:") ? "C:\\Users\\op\\AppData\\Local\\Temp\\kael-setup-1752.log" : `${installPath.slice(0, 2)}\\kael-setup-1752.log`;

  /* ------------------------------------------------------------------- render */
  return (
    <div className="relative h-full w-full overflow-hidden">
      <Backdrop />

      <div className="absolute inset-0 grid place-items-center">
        <div
          className={cn("transition-[transform,opacity] duration-300 ease-[var(--ease-out-kael)]", dragging && "duration-0")}
          style={{
            width: W,
            height: H,
            transform: `translate(${offset.x}px, ${offset.y}px) scale(${(windowState === "normal" ? scale : scale * 0.94).toFixed(3)})`,
            opacity: windowState === "normal" ? 1 : 0,
            pointerEvents: windowState === "normal" ? "auto" : "none",
          }}
        >
          <div className="relative flex h-full w-full flex-col overflow-hidden rounded-[16px] border border-white/[0.1] bg-[#0a0c0b]/97 shadow-[var(--shadow-window)] backdrop-blur-xl">
            <span className="pointer-events-none absolute inset-x-14 top-0 h-px bg-gradient-to-r from-transparent via-phos-500/40 to-transparent" />

            <TitleBar
              dragging={dragging}
              onDragStart={onDragStart}
              onMinimize={() => setWindowState("minimized")}
              onClose={() => setCloseModal(true)}
              overlays={
                <>
                  <Button
                    size="sm"
                    variant={specOpen ? "warn" : "quiet"}
                    icon={<Book width={12} height={12} />}
                    onClick={() => {
                      setSpecOpen((v) => !v);
                      setScenOpen(false);
                    }}
                  >
                    spec sheet
                  </Button>
                  <IconButton
                    label="Preview scenarios"
                    active={scenOpen}
                    onClick={() => {
                      setScenOpen((v) => !v);
                      setSpecOpen(false);
                    }}
                  >
                    <Sliders width={14} height={14} />
                  </IconButton>
                  <Chip tone={running ? "phos" : scenario === "failure" ? "err" : scenario === "clean" ? "neutral" : "amber"} className="hidden sm:inline-flex">
                    {running ? "installing" : scenario === "clean" ? "clean machine" : scenario === "failure" ? "failure staged" : scenario === "lowDisk" ? "low disk" : scenario === "upgrade" ? "upgrade path" : "av interference"}
                  </Chip>
                </>
              }
            />

            <div className="relative flex min-h-0 flex-1">
              <StepRail
                steps={STEPS}
                current={mode === "uninstall" ? -1 : step}
                reached={mode === "uninstall" ? STEPS.length : step}
                onSelect={(i) => {
                  if (mode === "uninstall" || running) return;
                  if (i > step) return;
                  goStep(i);
                }}
                mode={mode}
                uninstallEnabled={canLeaveInstall}
                onUninstall={() => {
                  if (!canLeaveInstall) return;
                  setMode("uninstall");
                  setUninstallStage("confirm");
                  setNotice(null);
                }}
              />

              <div className="flex min-w-0 flex-1 flex-col px-5 pt-4 pb-0">
                {/* ------------------------------------------------- step heading */}
                {mode === "install" && step !== 4 ? (
                  <header className="anim-step mb-3.5 flex items-start gap-4">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-txt-3">
                          step {step + 1} / {STEPS.length}
                        </span>
                        <span className="h-px w-6 bg-white/12" />
                        <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-phos-500/80">{STEPS[step].sub}</span>
                      </div>
                      <h1 className="mt-1.5 flex items-baseline font-display text-[22px] font-bold leading-tight tracking-[-0.015em] text-txt-1">
                        {STEP_META[step].title}
                        <span className="caret ml-2.5 h-[17px] w-[9px] text-phos-500" />
                      </h1>
                      <p className="mt-1 font-mono text-[11px] leading-[17px] tracking-tight text-txt-3">{STEP_META[step].sub}</p>
                    </div>
                  </header>
                ) : null}

                {notice ? (
                  <div className="mb-3">
                    <Notice
                      tone={notice.tone}
                      icon={notice.tone === "phos" ? <Check width={15} height={15} /> : <Warn width={15} height={15} />}
                      title={notice.title}
                      action={
                        notice.action ? (
                          <Button size="sm" variant="ghost" onClick={notice.action.fn}>
                            {notice.action.label}
                          </Button>
                        ) : (
                          <button
                            type="button"
                            aria-label="Dismiss notice"
                            onClick={() => setNotice(null)}
                            className="font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3 transition hover:text-txt-1"
                          >
                            dismiss
                          </button>
                        )
                      }
                    >
                      {notice.body}
                    </Notice>
                  </div>
                ) : null}

                {/* ------------------------------------------------------- step body */}
                <div ref={bodyRef} tabIndex={-1} className="flex min-h-0 flex-1 flex-col outline-none">
                  {mode === "uninstall" ? (
                    uninstallStage === "confirm" ? (
                      <Uninstall
                        targetPath={installPath}
                        keepSettings={keepSettings}
                        setKeepSettings={setKeepSettings}
                        installedMb={412.7}
                      />
                    ) : uninstallStage === "running" ? (
                      <Installing
                        status={engine.status}
                        pct={engine.pct}
                        logs={engine.logs}
                        elapsedMs={engine.elapsedMs}
                        phase={engine.phase}
                        variant="uninstall"
                        targetPath={installPath}
                        onCancel={() => setCancelModal(true)}
                        onRetry={() => retryInstall("uninstall")}
                        onCopyLog={copyLog}
                        showFailureLog={showFailureLog}
                        onShowFailureLog={setShowFailureLog}
                      />
                    ) : (
                      <Finish
                        variant="uninstall"
                        elapsedMs={engine.elapsedMs}
                        targetPath={installPath}
                        components={components}
                        upgrade={false}
                        preserveSettings={keepSettings}
                        launch={false}
                        setLaunch={setLaunch}
                        purge={purge}
                        setPurge={(v) => {
                          setPurge(v);
                          toast(v ? "residual data queued for purge" : "residual data will be kept");
                        }}
                        onShowLog={() => setLogModal(true)}
                        logPath={logPath}
                      />
                    )
                  ) : step === 0 ? (
                    <Welcome
                      onInstall={startInstall}
                      onReleaseNotes={() => {
                        setSpecOpen(true);
                        toast("spec sheet open — tokens, scale & asset manifest");
                      }}
                    />
                  ) : step === 1 ? (
                    <License accepted={accepted} onAccept={setAccepted} onScrollProgress={setLicensePct} />
                  ) : step === 2 ? (
                    <Location
                      path={installPath}
                      setPath={setInstallPath}
                      lowDisk={lowDisk}
                      upgrade={upgrade}
                      preserveSettings={preserveSettings}
                      setPreserveSettings={setPreserveSettings}
                      avBlock={avBlock}
                      onValidity={setPathStatus}
                      onJumpToPath={() => {
                        const el = document.querySelector<HTMLInputElement>('input[aria-describedby="path-validation"]');
                        el?.focus();
                        el?.select();
                        toast("focus moved to destination path");
                      }}
                    />
                  ) : step === 3 ? (
                    <Components components={components} setComponents={setComponents} avBlock={avBlock} />
                  ) : step === 4 ? (
                    <Installing
                      status={engine.status}
                      pct={engine.pct}
                      logs={engine.logs}
                      elapsedMs={engine.elapsedMs}
                      phase={engine.phase}
                      variant="install"
                      targetPath={installPath}
                      onCancel={() => setCancelModal(true)}
                      onRetry={() => retryInstall("install")}
                      onCopyLog={copyLog}
                      showFailureLog={showFailureLog}
                      onShowFailureLog={setShowFailureLog}
                    />
                  ) : (
                    <Finish
                      variant="install"
                      elapsedMs={engine.elapsedMs}
                      targetPath={installPath}
                      components={components}
                      upgrade={upgrade}
                      preserveSettings={preserveSettings}
                      launch={launch}
                      setLaunch={setLaunch}
                      purge={purge}
                      setPurge={setPurge}
                      onShowLog={() => setLogModal(true)}
                      logPath={logPath}
                    />
                  )}
                </div>

                {/* --------------------------------------------------------- footer */}
                <footer className="hair-t -mx-5 mt-3.5 flex h-[56px] shrink-0 items-center gap-3 bg-[linear-gradient(180deg,rgb(255_255_255/0.012),transparent)] px-5">
                  <span className="hidden items-center gap-3 font-mono text-[10px] uppercase tracking-[0.14em] text-txt-3 lg:flex">
                    <span className="flex items-center gap-1.5">
                      <Key width={12} height={12} /> Tab
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="rounded-[4px] border border-white/12 bg-white/[0.04] px-1.5 py-[1px] text-[9.5px]">↵</span> next
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="rounded-[4px] border border-white/12 bg-white/[0.04] px-1.5 py-[1px] text-[9.5px]">esc</span> close
                    </span>
                  </span>
                  <span className="flex-1" />

                  {mode === "install" && step > 0 && step !== 4 ? (
                    <Button variant="ghost" icon={<ChevronLeft width={13} height={13} />} onClick={() => goStep(step - 1)}>
                      Back
                    </Button>
                  ) : null}

                  {running || (mode === "uninstall" && uninstallStage === "running") ? (
                    <Button variant="warn" onClick={() => setCancelModal(true)}>
                      Cancel install
                    </Button>
                  ) : (
                    <div className="flex items-center gap-2">
                      {mode === "install" && step === 0 ? (
                        <>
                          <span className="hidden font-mono text-[10px] uppercase tracking-[0.16em] text-txt-3 xl:inline">
                            enter ↵ continues to the licence
                          </span>
                          <Button variant="ghost" onClick={() => setCancelModal(true)}>
                            Exit setup
                          </Button>
                        </>
                      ) : mode === "install" && step < 4 ? (
                        <Button variant="quiet" onClick={() => setCancelModal(true)}>
                          Cancel
                        </Button>
                      ) : mode === "uninstall" && uninstallStage !== "done" ? (
                        <Button
                          variant="quiet"
                          onClick={() => {
                            setMode("install");
                            setStep(3);
                          }}
                        >
                          Back to install
                        </Button>
                      ) : null}

                      {footerPrimary ? (
                        <Button
                          variant={footerPrimary.variant}
                          size={step === 0 || step === 5 ? "lg" : "md"}
                          disabled={footerPrimary.disabled}
                          iconRight={footerPrimary.variant === "primary" ? <ChevronRight width={13} height={13} /> : undefined}
                          onClick={footerPrimary.fn}
                        >
                          {footerPrimary.label}
                        </Button>
                      ) : null}
                    </div>
                  )}
                </footer>
              </div>

              <SpecSheet open={specOpen} onClose={() => setSpecOpen(false)} />
              <ScenarioPanel
                open={scenOpen}
                scenario={scenario}
                setScenario={(s) => {
                  setScenario(s);
                  toast(
                    s === "clean"
                      ? "scenario: clean install"
                      : s === "lowDisk"
                        ? "scenario: 180 MB free on C:"
                        : s === "upgrade"
                          ? "scenario: v1.0.5 detected at target"
                          : s === "avBlock"
                            ? "scenario: defender scanning payload"
                            : "scenario: will fail at 62%",
                  );
                }}
                speed={speed}
                setSpeed={setSpeed}
                onClose={() => setScenOpen(false)}
              />
            </div>

            <StatusStrip
              tone={running ? "busy" : engine.status === "failed" ? "warn" : engine.status === "done" ? "ok" : "idle"}
              left={
                running
                  ? `${engine.pct.toFixed(1)}% · ${fmtClock(engine.elapsedMs)} elapsed · ${engine.logs.length} log lines · webview2 1.0.2903.40`
                  : `${mode === "install" ? "KAEL Setup" : "KAEL Uninstall"} v1.0.5 · payload 1.4 MB embedded · no network access · audit log ${logPath.split("\\").pop()}`
              }
              right={`per-monitor dpi aware · scale ${(scale * 100).toFixed(0)}% · win 11 24h2`}
            />

            {/* ------------------------------------------------------------- modals */}
            <Modal
              open={cancelModal}
              tone={running ? "warn" : "default"}
              eyebrow={running ? "operation in progress" : "setup"}
              title={running ? "Cancel setup?" : "Exit KAEL Setup?"}
              onClose={() => setCancelModal(false)}
              actions={
                <>
                  <Button variant="ghost" data-autofocus onClick={() => setCancelModal(false)}>
                    Resume setup
                  </Button>
                  <Button
                    variant="warn"
                    icon={<Warn width={13} height={13} />}
                    onClick={() => {
                      setCancelModal(false);
                      if (running) {
                        engine.abort();
                        toast("rollback started — reverting staged changes");
                      } else if (mode === "uninstall") {
                        setMode("install");
                        setStep(3);
                      } else {
                        setWindowState("closed");
                      }
                    }}
                  >
                    {running ? "Cancel & roll back" : "Discard & exit"}
                  </Button>
                </>
              }
            >
              {running ? (
                <span>
                  KAEL is at <span className="text-amber-300">{engine.pct.toFixed(0)}%</span> — {engine.logs.length} log lines written. Cancelling triggers a
                  safe rollback: staged files are deleted, registry writes reverted, shortcuts never created. The machine is left exactly as it was.
                </span>
              ) : (
                <span>
                  No files have been written yet. Your path, component and licence selections will be discarded. The audit log stays in{" "}
                  <span className="text-txt-1">%TEMP%</span> if you need it for a support ticket.
                </span>
              )}
            </Modal>

            <Modal
              open={closeModal}
              title="Close KAEL Setup?"
              eyebrow="window"
              onClose={() => setCloseModal(false)}
              actions={
                <>
                  <Button variant="ghost" data-autofocus onClick={() => setCloseModal(false)}>
                    Stay in setup
                  </Button>
                  <Button variant="warn" onClick={() => {
                    setCloseModal(false);
                    setWindowState("closed");
                  }}>
                    Close window
                  </Button>
                </>
              }
            >
              <span>
                Closing the installer leaves nothing installed and nothing changed. You can relaunch{" "}
                <span className="text-txt-1">kael-setup.exe</span> at any time — the embedded payload works fully offline.
              </span>
            </Modal>

            <Modal
              open={logModal}
              title="Setup audit log"
              eyebrow={`${engine.logs.length} lines · ${fmtClock(engine.elapsedMs)}`}
              onClose={() => setLogModal(false)}
              actions={
                <>
                  <Button
                    variant="ghost"
                    icon={<Copy width={12} height={12} />}
                    onClick={() => copyLog()}
                  >
                    Copy log
                  </Button>
                  <Button variant="primary" data-autofocus onClick={() => setLogModal(false)}>
                    Close
                  </Button>
                </>
              }
            >
              <pre className="scroll-thin max-h-[300px] overflow-auto rounded-[10px] border border-white/[0.08] bg-black/60 p-3 font-mono text-[10.5px] leading-[17px] whitespace-pre-wrap text-txt-2">
                {logToText(engine.logs, headerFor(mode))}
              </pre>
            </Modal>
          </div>
        </div>
      </div>

      {/* --------------------------------------------------------- minimized pill */}
      {windowState === "minimized" ? (
        <div className="absolute bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3">
          <button
            type="button"
            onClick={() => setWindowState("normal")}
            className="anim-toast flex items-center gap-3 rounded-full border border-white/[0.1] bg-[#0b0f0d]/95 py-2 pl-3 pr-4 shadow-[0_20px_50px_-20px_rgb(0_0_0/0.9)] backdrop-blur-xl transition hover:border-phos-500/40"
          >
            <span className={cn("grid h-7 w-7 place-items-center rounded-[8px] border", running ? "border-phos-500/40 bg-phos-900/60 text-phos-300" : "border-white/10 bg-white/[0.04] text-txt-2")}>
              <Terminal width={14} height={14} />
            </span>
            <span className="text-left">
              <span className="block font-mono text-[11.5px] tracking-tight text-txt-1">KAEL Setup · v1.0.5</span>
              <span className="block font-mono text-[10px] tracking-tight text-txt-3">
                {running ? `installing ${engine.pct.toFixed(0)}% — click to restore` : "minimized — click to restore"}
              </span>
            </span>
          </button>
        </div>
      ) : null}

      {/* ------------------------------------------------------------ closed pane */}
      {windowState === "closed" ? (
        <div className="absolute inset-0 grid place-items-center">
          <div className="anim-rise w-[520px] rounded-glass border border-white/[0.08] bg-white/[0.02] p-6 text-center backdrop-blur-xl">
            <div className="mx-auto grid h-11 w-11 place-items-center rounded-[13px] border border-phos-500/30 bg-phos-900/50 text-phos-300">
              <Spark width={19} height={19} />
            </div>
            <h2 className="mt-3.5 font-display text-[17px] font-semibold tracking-tight text-txt-1">Setup exited</h2>
            <p className="mt-1.5 font-mono text-[11px] leading-[18px] text-txt-3">
              {engine.status === "done"
                ? "Exit code 0 — nothing left running. The audit log was written to " + logPath
                : "Exit code 0 · no changes were written to this machine."}
            </p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <Button
                variant="primary"
                icon={<Rocket width={14} height={14} />}
                onClick={() => {
                  setWindowState("normal");
                  setMode("install");
                  setStep(0);
                  setAccepted(false);
                  setNotice(null);
                  engine.reset();
                  startedRef.current = false;
                  handledRef.current = null;
                }}
              >
                Relaunch kael-setup.exe
              </Button>
            </div>
            <div className="mt-5 flex items-center justify-center gap-4 font-mono text-[10px] uppercase tracking-[0.18em] text-txt-3">
              <span className="flex items-center gap-1.5">
                <Check width={11} height={11} className="text-phos-500/80" /> offline
              </span>
              <span className="flex items-center gap-1.5">
                <Check width={11} height={11} className="text-phos-500/80" /> no telemetry
              </span>
              <span className="flex items-center gap-1.5">
                <MicroLabel>build 26100</MicroLabel>
              </span>
            </div>
          </div>
        </div>
      ) : null}

      {/* ------------------------------------------------------------------ toasts */}
      <div className="pointer-events-none absolute bottom-5 right-5 z-50 flex flex-col items-end gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="anim-toast flex items-center gap-2.5 rounded-[11px] border border-white/[0.1] bg-[#0b0f0d]/95 px-3.5 py-2.5 shadow-[0_20px_50px_-20px_rgb(0_0_0/0.95)] backdrop-blur-xl"
          >
            <Check width={13} height={13} className="text-phos-400" />
            <span className="font-mono text-[11px] tracking-tight text-txt-2">{t.text}</span>
          </div>
        ))}
      </div>

      {/* scenario quick-note on the backdrop */}
      <div className="pointer-events-none absolute left-5 top-5 z-10 hidden flex-col gap-1.5 md:flex">
        <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-txt-3">
          <span className="h-[6px] w-[6px] rounded-full bg-phos-500/80" /> kael setup · terminal luxe
        </span>
        <span className="font-mono text-[10px] tracking-tight text-txt-3/80">
          drag the title bar · “spec sheet” opens the token manifest · tab through every control
        </span>
      </div>
    </div>
  );
}
